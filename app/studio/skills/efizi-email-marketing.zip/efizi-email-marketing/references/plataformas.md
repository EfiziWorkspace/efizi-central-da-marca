# Plataformas de marketing — como entregar e o descadastro

O mesmo casco serve pras plataformas; muda **como você entrega** e **como o descadastro é resolvido**. Escolha pelo destino da campanha.

## Shopify Email (campanha / blast) — o padrão hoje
- **Cobra por ENVIO** (grátis até ~10k/mês, depois ~US$1/mil). Bom pra lista grande com envio baixo.
- **Não dá pra criar/disparar campanha pela API** — composição e envio são no admin (Marketing → Criar campanha → Shopify Email).
- **Como colar o HTML:** o app é montado em blocos; adicione uma seção **"Liquid personalizado" / "Código personalizado"** e **cole o casco inteiro**. O editor pode remover `<style>` (fontes caem no fallback Arial, mobile encolhe menos) — mas como o casco é **estilo inline**, o visual se mantém.
- **Descadastro:** o Shopify Email adiciona o rodapé obrigatório **sozinho** → **REMOVA** o `{{unsubscribe}}` do casco pra não ficar link morto.
- **Segmento:** use "Email subscribers" ou "Inscritos na Newsletter" (já existem na loja).
- **Sempre "Enviar teste"** pro seu e-mail antes; o editor pode mexer no HTML.

## Klaviyo / Omnisend (fluxos automatizados)
- **Cobram por CONTATO armazenado** (não por envio) → caro pra base grande e dormente. Só compensa quando e-mail vira canal de receita sério (Klaviyo é o teto; Omnisend o custo-benefício).
- Fazem nativo: **carrinho abandonado**, **voltou ao estoque**, **cupom único por pessoa** (sincronizado com o Shopify).
- **Descadastro:** use a tag de unsubscribe da própria plataforma no rodapé.
- **Editor HTML:** ambos aceitam colar HTML custom (melhor que o Shopify Email pra isso).

## Restock Rocket (STOQ) — o "voltou ao estoque"
- O e-mail de back-in-stock é enviado **pelo app** (template dele), não pelo Shopify Email. Custo acompanha a **demanda real** (gente esperando um produto esgotado), não a base inteira.
- Canais: e-mail, SMS, **WhatsApp** (decisivo no Brasil), push. **Anexa cupom** na notificação.
- O botão "Avise-me" entra nas PDPs esgotadas — **complementa** o aviso do seletor de capacidade (que manda pro tamanho disponível). Ver memória do rebrand.
- Setup: instalar (ação do cliente) → estilizar na marca (`#FF4000`, Manrope) → plugar cupom (gerar no Shopify) → testar (zerar estoque → assinar → repor → confere alerta+cupom).

## Regra de custo (decisão da Efizi)
Lista grande + envio baixo → **Shopify Email (por envio) + Restock Rocket (por demanda)**, e cupom gerado no Shopify. NÃO pagar Klaviyo/Omnisend por contato de uma base que quase não envia. Reavaliar só se o volume de envio crescer muito.

## Cupom
- Gerar no Shopify (via API `discountCodeBasicCreate` ou lote) — único ou compartilhado.
- **Único por pessoa dentro do fluxo** = só Klaviyo/Omnisend fazem bem. No Shopify Email/Restock Rocket, o padrão é **código compartilhado** (com validade curta resolve 90%).

## Assunto + preheader (todo blast)
- Entregue **2-3 variações de assunto** pra A/B. Curto, sem clickbait, benefício claro.
- Preheader = 1 linha de reforço (o casco tem o slot oculto). Ex.: "Instala no solo, dentro da norma. A partir de R$ 1.999."
