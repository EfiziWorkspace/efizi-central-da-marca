#!/usr/bin/env bash
# Renderiza um HTML de e-mail Efizi em PNG, pra conferir o visual antes de entregar.
# Uso:  preview.sh entrada.html [saida.png]
# Dica: os placeholders ({{ $json.x }}, [TAG], Liquid) aparecem como texto cru no preview.
#       Pra um preview realista, faça uma cópia temporária com valores de exemplo via sed ANTES:
#         sed -E 's/\{\{ \$json\.cliente_nome \}\}/Valdeci Jose de Souza/g; ...' entrada.html > /tmp/preview.html
#       e renderize /tmp/preview.html.
set -euo pipefail

IN="${1:?uso: preview.sh entrada.html [saida.png]}"
OUT="${2:-${IN%.html}.png}"

# Acha o Chrome/Chromium (Mac primeiro, depois PATH)
CHROME=""
for c in \
  "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome" \
  "/Applications/Chromium.app/Contents/MacOS/Chromium" \
  "$(command -v google-chrome 2>/dev/null || true)" \
  "$(command -v chromium 2>/dev/null || true)" \
  "$(command -v chromium-browser 2>/dev/null || true)"; do
  if [ -n "$c" ] && [ -x "$c" ]; then CHROME="$c"; break; fi
done
[ -n "$CHROME" ] || { echo "Chrome/Chromium não encontrado. Instale o Google Chrome." >&2; exit 1; }

# 680 de largura casa com o card de 600 + respiro; fundo transparente pra pegar o creme do body.
"$CHROME" --headless --disable-gpu \
  --screenshot="$OUT" \
  --window-size=680,1200 \
  --hide-scrollbars \
  --default-background-color=00000000 \
  "file://$(cd "$(dirname "$IN")" && pwd)/$(basename "$IN")" 2>/dev/null

echo "preview salvo: $OUT"
