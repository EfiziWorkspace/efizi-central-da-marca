---
name: efizi-email-marketing
description: >-
  Monta e-mail de MARKETING / ciclo de vida da Efizi no casco de marca — campanha (blast
  promocional, lançamento, oferta), boas-vindas, carrinho abandonado, voltou ao estoque (back-in-stock)
  e winback/reativação. Use SEMPRE que o pedido resultar num e-mail PROMOCIONAL que vai pra uma lista
  ou fluxo: "faz uma campanha de e-mail", "e-mail de lançamento do produto X", "e-mail de boas-vindas",
  "e-mail de carrinho abandonado", "avise-me quando voltar / back-in-stock", "e-mail de winback",
  "blast pra base", "newsletter", "promoção por e-mail", "monta o HTML da campanha" — mesmo sem citar
  "Efizi" ou "casco". Destinos: Shopify Email (colar no bloco Liquid), Klaviyo/Omnisend, Restock Rocket.
  NÃO use pra e-mail TRANSACIONAL (NF-e, boleto, pedido, pagamento, redefinição de senha → efizi-email),
  nem pra deck/painel/landing (documento-html-efizi), nem pra tema/PDP Shopify (efizi-pdp-descricao).
---

# E-mail de marketing da Efizi

Marketing é diferente de transacional (isso é `efizi-email`). Aqui o e-mail é **promocional**: vai pra uma lista ou fluxo, tem que **persuadir** (hero + oferta + CTA) e **por lei precisa de descadastro**. Mesmo casco de marca, estrutura e regras diferentes. Seu trabalho é adaptar o conteúdo da oferta — não reinventar a marca.

## Fluxo

1. **Descubra o destino** (muda como você entrega e o descadastro): **Shopify Email** (campanha, cola no bloco Liquid), **Klaviyo/Omnisend** (fluxo automatizado), **Restock Rocket** (o "voltou ao estoque" é o app que envia). Detalhes em [references/plataformas.md](references/plataformas.md).
2. **Duplique o casco**: copie `assets/casco-marketing.html` pro projeto (ex.: `email-html/<campanha>.html`). Não comece do zero.
3. **Adapte os slots**: selo, H1 (1 span laranja), hero (imagem hospedada — ver abaixo), lede, oferta/preço, CTA, blocos de benefício, stat, CTA final. Header/footer/paleta ficam.
4. **Hospede a imagem do hero** no CDN do Shopify (fluxo abaixo) e use a **URL absoluta** no `<img>`. E-mail NÃO carrega imagem local nem base64.
5. **CTA com UTM** apontando pro destino (landing/PDP): `?utm_source=email&utm_medium=email&utm_campaign=<slug>`.
6. **Renderize o preview** e leia o PNG (ver "Preview"). Confira a régua de marca antes de entregar.
7. **Entregue** o HTML + o PNG + o assunto/preheader + a que segmento vai.

## Regras de marca (iguais à transacional — não reinvente)
- **Paleta:** fundo creme `#F5F3EF` · card branco · ink `#0A0A0A` · secundário `#6B6660`/`#9A968F`. Laranja `#FF4000` = ênfase/CTA. Verde `#1E874B` = economia/WhatsApp. Amarelo `#FFD500` = só faixa PIX/selo. **Uma ênfase por peça.**
- **Manrope** (`@import` + fallback `Manrope,Arial,Helvetica,sans-serif`). Corpo ~17-18px (público 40+).
- **Copy:** **sem travessão (—)**, nunca. Sentence case. Tom próximo ("a gente resolve"). Sem "Prezado/Atenciosamente".
- **Litragem específica** ("1.500L", não "grande"). **Evitar "exclusivo/premium"** → usar "Só na Efizi". Slogan/descritor B2C, nunca o B2B em e-mail de cliente.

## Regras SÓ de marketing (o que difere do transacional)
- **Descadastro obrigatório.** Como resolver muda por plataforma:
  - **Shopify Email** adiciona o rodapé de descadastro **sozinho** → **REMOVA** qualquer `{{unsubscribe}}` do casco (senão vira link morto).
  - **Klaviyo/Omnisend** → use a tag de unsubscribe da plataforma no rodapé.
- **Uma oferta por e-mail.** Um CTA principal. Não empilhar promoções.
- **Assunto + preheader** decidem a abertura. Entregue **2-3 variações de assunto** pra A/B. Preheader = resumo de 1 linha (o casco já tem o slot oculto).
- **Hero é imagem achatada e hospedada** (cena + produto numa imagem só). Layer com produto por cima via CSS NÃO funciona em e-mail. Regra da marca: produto é **foto real do fabricante**, IA só faz o fundo/cena.
- **Headline e CTA são texto vivo** (aguentam imagem bloqueada — padrão em muitos clientes). Nunca só imagem.
- **UTM sempre** no CTA, pra medir a campanha.

## Fluxo de imagem: hospedar o hero no CDN do Shopify
E-mail exige URL absoluta. Render o hero (HTML→PNG via Chrome headless, ver preview.sh) e suba pro Shopify Files:
1. `stagedUploadsCreate` (GraphQL) → pega `url` + `parameters` + `resourceUrl`.
2. **Suba via curl montando os `-F` por SCRIPT lendo o JSON** — NUNCA copie a policy/assinatura na mão (1 char errado = `InvalidPolicyDocument`). Ex.: python lê os parameters e monta o `curl -F`.
3. `fileCreate` com `originalSource: resourceUrl` e `filename` cuja **extensão bate com a da origem** (senão "extensão precisa corresponder à origem").
4. Pegue a `image.url` final (`fileUrl` query) e use no `<img src>`.
> Se o Higgsfield MCP estiver autenticado, `media_upload` (PUT presigned) é um atalho mais simples que o staged upload. Detalhes e exemplo em plataformas.md.

## Preview
Igual à transacional. Como o casco de marketing tem placeholders de conteúdo (não de dados), geralmente já dá pra renderizar direto:
```bash
bash ~/.claude/skills/efizi-email-marketing/scripts/preview.sh email-html/campanha.html /tmp/preview.png
```
Depois **leia o PNG** e confira: hero hospedado aparece, 1 ênfase laranja, sem travessão, CTA claro, oferta legível, rodapé com espaço pro descadastro.

## Referência real no repo (o canônico)
- `email-html/email-biodigestor-claro.html` — campanha do Biodigestor Zero Escavação (a base deste casco): selo, hero hospedado, H1 com span laranja, benefícios com check, bloco 89% laranja, "3 em 1", confiança, CTA final Ink, rodapé. É o molde.
- Versões escura e híbrida da mesma campanha em `email-html/` (variações de clima).

## Erros que já custaram tempo (não repita)
- **Base64 @font-face NÃO funciona em e-mail** (clientes removem `<style>`) — use `@import` + fallback Arial. (É o oposto da `documento-html-efizi`, que é offline/base64 pra documento de navegador.)
- **Imagem local/embutida quebra** — tem que ser URL absoluta hospedada.
- **Copiar policy do staged upload na mão** corrompe a assinatura — monte o curl por script lendo o JSON.
- **Deixar `{{unsubscribe}}` no e-mail do Shopify Email** vira link morto (ele já põe o dele).
- **Teste seguro:** "Enviar teste" pro seu e-mail e abra em Gmail + Outlook + celular ANTES do disparo em massa. O editor da plataforma pode mexer no HTML.
- **Domínio não autenticado** (SPF/DKIM em efizi.com.br) → cai em spam no blast. Conferir antes do envio grande.
