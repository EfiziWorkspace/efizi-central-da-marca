---
name: carrossel-efizi
description: >
  Cria um CARROSSEL/peça de marketing da Efizi do zero, no padrão híbrido aprovado
  (IA gera só a imagem sem texto → tipografia real por cima em código: logo oficial +
  Manrope + acentos certos + CTA "Ver no site"). Use SEMPRE que o pedido for criar
  peça/carrossel/anúncio do zero: "cria um carrossel sobre X", "monta uma peça de
  feed/story", "faz um anúncio do Biodigestor", "carrossel pro Instagram/LinkedIn",
  "peça de marketing sobre Y" — mesmo sem citar Higgsfield. NÃO use para ADAPTAR uma
  peça pronta pra vários formatos (skill desdobrar), nem pra pôr site na tela de um
  dispositivo (mockup-tela), nem pra geração de imagem avulsa sem tipografia da marca
  (higgsfield-generate), nem pra e-mail/deck/landing (efizi-email / documento-html-efizi).
---

# Carrossel / peça de marketing da Efizi (híbrido IA + tipografia real)

Regra-mãe (jul/2026): **nunca IA pura pra texto.** A IA desenha um "efizi" falso, uma
fonte só parecida e come acentos. O padrão aprovado é **híbrido**: IA gera **só a
imagem** (produto real + cena/luz, sem texto/logo), e **eu sobreponho por código** o
logo oficial + Manrope + acentos certos. Ele reprovou tanto HTML puro (flat) quanto IA
pura (logo/fonte falsos). Detalhes em [[feedback-pecas-hibrido-ia-tipografia]].

## Pré-voo
- `command -v higgsfield` (fica em `~/.npm-global/bin/higgsfield`). Se der "Not
  authenticated", avisar o usuário pra rodar `higgsfield auth login` (não manuseio credencial).
- Chrome pra render do overlay: `/Applications/Google Chrome.app/Contents/MacOS/Google Chrome --headless=new`.
- Manrope e logos: `design-system/logo/efizi-logo.svg` (ink+dot laranja) e
  `efizi-logo-white.svg`. Manrope embutida em base64 (mesma dos outros HTMLs).

## Passos

### 1. Roteiro (fecha ANTES de gerar imagem)
Definir a sequência de slides e a copy. Arco típico de carrossel:
**capa (gancho) → dado/dor → contexto → solução (produto) → prova → CTA**.
Copy na marca: **sem travessão "—"** ([[copy-efizi-sem-travessao]]), sem formalidade,
**acentos sempre certos** (grátis, Até, cartão, escavação, superfície, água), CTA
padrão **"Ver no site"**. Água & esgoto fora da rede (DNA em `dna/`,
[[efizi-reposicionamento-saneamento]]). Alinhar a copy no chat antes de gastar crédito
([[workflow-fechar-versao-antes-de-salvar]]).

### 2. Imagens-base da IA (SEM texto/logo)
- **Cena/fundo** → Nano Banana Pro (`nano_banana_2`, `--resolution 2k`), padrão de
  imagem ([[feedback-geracao-imagem-higgsfield]]): **foco profundo, nítido de ponta a
  ponta, sem bokeh/DOF raso** (a headline entra por cima, não pode borrar).
- **Produto real** (catálogo Shopify — buscar, ex.: "escavação" p/ Biodigestor MAX
  Zero) → `gpt_image_2` com `--image <ref>` (preserva o produto; **manter proporção,
  não esticar**).
- Todo prompt termina com: **`CRITICAL: NO text, NO words, NO logo, NO watermark`**.
- **Chain de referência** entre slides (passar o slide anterior como `--image`) pra o
  carrossel ficar visualmente coeso.
- Mecânica CLI: `gpt_image_2` = 7 créditos, **cap 8 jobs concorrentes**, **NÃO usar
  `--wait`** (estoura timeout de 2min) → submeter `--json` (devolve id), `generate get
  <id>` e baixar a `*.png`. `nano_banana_2` = 2 créditos, `--wait` ok em imagem única.
  Se o download falhar, o job existe: `generate list --image --json` → casar prompt →
  `result_url`. Guardar as bases limpas (dá pra reeditar texto sem gastar crédito).

### 3. Overlay tipográfico (código → o que dá a cara da marca)
Gerador Python monta **HTML+CSS → PNG via Chrome headless** (modelo real:
`pecas/higgsfield/finais_oficiais/_gerador_logo.py`, `pecas/**/_gerador*.py`):
- imagem da IA como `background-size:cover`;
- **logo oficial** (SVG em base64: `efizi-logo.svg` em fundo claro, `efizi-logo-white.svg`
  em fundo escuro) num canto (âncoras TL/TR/TC/BL/BR, ~40px de margem);
- **todo o texto em Manrope** (base64 @font-face), acentos certos, acento laranja
  `#FF4000`, ink `#0A0A0A`, creme `#F5F3EF`;
- se a base tiver logo/texto residual da IA, cobrir com um **patch** da cor do fundo
  (truque do gerador: retângulo na cor exata → some);
- CTA **"Ver no site"**. Texto fica **editável** (regerar overlay sem novo crédito).

### 4. Conferir (sempre)
Abrir os PNGs e checar: **logo é o oficial** (não o falso da IA), **fonte é Manrope**,
**acentos certos**, produto **não esticado**, contraste do texto ok. Story 9:16 →
respeitar safe-zones do Meta (topo ~260px, base ~420px livres; CTA é do Meta, nada na arte).

### 5. Formatos e entrega
- Feed **1:1** (2048px) é o principal; Stories/Reels **9:16**; **4:5** quando pedir.
- Salvar numerado em **`carrossel-proof/<NOME>/`** (`01-capa.png`, `02-...`, …), como
  os existentes (CARROSSEL-FINAL, AGRO-ESCASSEZ). Opcional: `_painel.jpg` com todos.
- A galeria pública do hub (`pecas/index.html`) referencia os carrosséis validados —
  o `build-pages.sh` copia `carrossel-proof/<NOME>` p/ o site; rodar `deploy-hub.sh` se
  for publicar ([[central-da-marca-hub]]).
- Pra **adaptar** o carrossel pronto em peças por plataforma (IG Feed/Stories/LinkedIn),
  usar a skill **`desdobrar`**.

## Guardrails travados
- **Preço fica FORA** das peças por enquanto (regionalizado): primeiro o padrão
  genérico, depois versiona por produto/preço/praça ([[pecas-marketing-max-estado]]).
- Produto = **real do catálogo**, nunca inventado; evitar caixa d'água em destaque
  (foco em tratamento) ([[feedback-imagens-sem-caixa-dagua]]).
- Nada de mistura de fonte: **tudo Manrope**. Nada de logo desenhado pela IA.

## Relacionadas
- `desdobrar` — adapta peça pronta pra formatos de plataforma (não cria do zero).
- `mockup-tela` — site na tela de dispositivo. `higgsfield-generate` — imagem avulsa.
- Motion/vídeo da peça (frames Chrome→ffmpeg, loop 10s) em [[feedback-video-motion-efizi]].
