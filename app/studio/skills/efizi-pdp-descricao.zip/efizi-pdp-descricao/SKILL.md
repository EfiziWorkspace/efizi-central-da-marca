---
name: efizi-pdp-descricao
description: Constrói e publica a descrição rica da PDP de um produto na loja Shopify da Efizi — copy da marca, dados do manual do fabricante, snippet Liquid escopado, metafields preenchidos e deploy verificado no tema. Use sempre que o pedido for "fazer/ajustar a página (ou a descrição) do produto X", "montar a PDP dessa linha", quando vier um manual ou catálogo de fabricante em PDF para virar página, quando uma descrição estiver mostrando dados/copy de outra marca, ou quando faltar preencher metafields de spec — mesmo que o usuário não diga as palavras "PDP", "snippet" ou "Liquid".
---

# Descrição rica de PDP — Efizi

A loja `efizi.com.br` (Shopify Plus, tema Horizon) troca a descrição crua do
produto por um **snippet Liquid próprio** por família de produto: hero, números
dinâmicos, cards de diferencial, "Serve pra você?", manual, FAQ e CTA. Esta skill
é o procedimento pra criar ou corrigir uma dessas páginas sem repetir os erros
que já custaram retrabalho.

## O fluxo

1. **Ler o manual do fabricante daquele produto.** É a única fonte de spec.
   PDFs grandes podem vir só como imagem — nesse caso leia as páginas com o
   Read (ele enxerga imagem); se tiver texto, `pypdf` extrai mais rápido.
2. **Levantar o estado atual do produto** — `productByHandle` ou busca por
   vendor/type: título, `productType`, `vendor`, `templateSuffix`, status,
   metafields existentes e a descrição atual. É aqui que se descobre dado
   fora do padrão (ver "Armadilhas").
3. **Escolher o arquétipo de narrativa** (abaixo) e conferir a linha do
   fabricante em `references/fabricantes.md`.
4. **Mockup HTML pra aprovação** em `pecas/mockups/` — só quando a narrativa é
   nova ou a copy é sensível. Se o usuário já viu o padrão e pediu "pode ir",
   vá direto pro snippet; ele conhece o layout e revisar duas vezes cansa.
5. **Escrever o snippet** em `shopify/theme-edits/snippets/`, partindo de
   `assets/template-descricao.liquid`.
6. **Ligar no switch** do `sections/main-product.liquid` e **preencher os
   metafields** de tudo que a página mostra.
7. **Deploy e verificar ao vivo** — ver `references/deploy.md`. Verificar é
   parte do trabalho, não opcional: quase todo bug desta família (chip errado,
   manual quebrado, seletor embaralhado) só apareceu ao abrir a página.

## A regra que mais causa retrabalho: spec é por fabricante

Um snippet com o nome de uma marca na copy **não pode** ser acionado por uma
regra que não checa a marca. Já aconteceu: a descrição do tanque Fortlev (que
diz "Fortlev" 8 vezes e fala em "tampa roscável de ¼ de volta") era acionada por
`type == 'Tanque' and title contains 'Polietileno'` — então tanque Fibromar e
Acqualimp apareciam vestidos de Fortlev, com a tampa errada.

Duas consequências práticas:

- **Todo gate inclui `product.vendor`.** Se a copy nomeia a marca, o gate
  também nomeia.
- **Nunca reaproveitar spec entre marcas.** Tampa, garantia, normas e flange
  mudam de fabricante pra fabricante (Fortlev trava com ¼ de volta, Fibromar
  trava por pressão, Acqualimp é tampa click). Se o manual daquele fabricante
  não traz o número, ele não vai pra página — a Fibromar cita só "ABNT e ASTM",
  então os códigos NBR/ASTM/ISO da Fortlev não podem ser copiados pra lá.

Consulte `references/fabricantes.md` antes de escrever qualquer parágrafo de
spec. Ao ler um manual novo, **acrescente a linha da marca lá** — é o que faz a
próxima página ser rápida.

## Arquétipos de narrativa

O layout é o mesmo; o que muda é o eixo do argumento. Escolha antes de escrever:

| Arquétipo | Exemplos | Eixo da copy |
|---|---|---|
| **Aéreo** | tanque de polietileno, caixa d'água | guardar água com segurança: tampa, anti-UV, norma, base firme |
| **Enterrado** | cisterna | não ocupa espaço + a obra de contenção (nunca só apoiar) |
| **Acessório** | leito de secagem | fecha o ciclo de outro equipamento; diz claramente o que ele **não** faz sozinho |
| **Kit** | caixa com filtro e boia | "o que vem na caixa": chega completa, sem comprar peça por fora |
| **Industrial** | tanques de diesel, vinho, leite | líquidos especiais, densidade, compatibilidade, **não é para água** |
| **Premium/tecnologia** | antibacteriano, água de chuva | a tecnologia específica + o benefício que ela compra |

Quando o produto tem um limite honesto, **diga o limite** em vez de esconder.
A caixa com filtro ganhou uma seção "O que o filtro faz (e o que não faz)"
deixando claro que ele retém sujeira mas não torna a água potável. Isso protege
a marca de overclaim e responde a dúvida real antes da compra.

## Copy da marca

- **Sem travessão (—)**: soa a texto de IA. Use vírgula, ponto ou dois-pontos.
- **Tom direto, sem formalidade**: nada de "Prezado" ou "Atenciosamente".
- **Só o que está no manual daquele fabricante.** Eficiência, norma e garantia
  sem laudo não entram, nem por analogia com produto parecido.
- Títulos de seção em pergunta funcionam bem ("O que vem na caixa?", "Por que a
  Água Limpa?", "Serve pra você?").
- Se um HTML for entregue pro usuário abrir fora da loja, embuta a Manrope em
  base64 — nada de CDN.

## Anatomia do snippet

Parta de `assets/template-descricao.liquid`. O que importa:

- **CSS inline escopado** numa classe raiz própria (`.efizi-desc-<algo>`) com
  prefixo curto nas classes filhas (`tk-`, `al-`, `ls-`). Escopo evita vazar
  estilo pra outras seções do tema, e o prefixo evita colisão entre snippets que
  possam coexistir na mesma página.
- **Números vêm de metafield**, nunca escritos na mão: `product.capacidade`,
  `altura`, `diametro`, `peso`, `efizi.garantia`. Assim uma página serve toda a
  linha (500 L a 20.000 L) sem duplicar arquivo.
- **Dimensão passa pelo `efizi-dim`**: `{% render 'efizi-dim', value: alt %}`
  converte "155 cm" em "1,55 m" e mantém em cm o que for menor que 1 m.
- **CTA delega pro botão real da buy box** com o seletor
  `.product-form__buttons button[name="add"]`, excluindo
  `.buy-together__product, slider-component, .quick-add`. Sem isso o botão
  adiciona o produto errado (o "leve junto") ao carrinho — bug real que chegou a
  ir ao ar. `<product-form>` avulso não funciona no Horizon.
- **Bloco de manual só existe se o PDF existir.** `file_url` devolve URL mesmo
  para asset inexistente, então `{% if manual_url != blank %}` não protege nada:
  ou o PDF foi subido, ou o bloco sai do arquivo.

## Ligar no `main-product.liquid`

O switch de descrição fica por volta da linha 1630, dentro do painel
`data-panel="desc"`. A ordem importa: **do mais específico para o mais genérico**,
porque o primeiro `elsif` que casar vence.

```liquid
{%- elsif template.suffix == 'reservatorio'
      and product.vendor == 'Fibromar'
      and product.type == 'Tanque'
      and product.title contains 'Polietileno' -%}
  {% render 'efizi-descricao-tanque-fibromar', product: product %}
```

Os **chips da buy box** (`efizi-bens`, por volta da linha 244) seguem a mesma
lógica de marca: a garantia lê `product.metafields.efizi.garantia`, e chips de
tampa/flange são condicionados por `product.vendor`. Se você criar uma página
nova, confira se os chips daquele produto continuam verdadeiros.

## Metafields

Regra do usuário: **tudo que a página mostra tem que estar no metafield**. Não
só porque a página lê de lá, mas porque a ficha técnica e futuras integrações
bebem da mesma fonte.

**Os dois namespaces são propositais, não duplicação.** A loja usa `product.*`
para spec física de catálogo (dimensão, peso, cor, material) e `efizi.*` para o
que a PDP exibe como argumento — as definições `efizi` inclusive se chamam
"… (chip PDP)" no admin. Confirme com `metafieldDefinitions(ownerType: PRODUCT,
namespace: "efizi")` se tiver dúvida, em vez de deduzir pelo que já está
preenchido: um campo vazio parece inexistente e leva ao campo errado.

A garantia é o caso que mais confunde, porque existe nos dois lugares:
**`efizi.garantia` é a que a PDP e o chip da buy box leem**; `product.garantia`
existe como definição mas está vazia na maioria dos produtos. Escrever no campo
errado gera um bug silencioso: a página cai no valor padrão e parece certa,
enquanto o chip continua anunciando outro prazo.

| Campo | Formato | Observação |
|---|---|---|
| `product.capacidade` | "1.000 litros" | |
| `product.altura` / `diametro` / `largura` | "155 cm" | sempre em cm; o `efizi-dim` converte na exibição |
| `product.peso` | "9 kg" | |
| `product.tipo_de_tampa` | "Tampa Click" | corrigir quando o dado herdado estiver errado |
| `efizi.garantia` | "Garantia de 10 anos" | texto completo; a página extrai o número |
| `efizi.tipo_agua` | "potável" / "de chuva" | controla o chip de água |
| `efizi.kit_incluso` | boolean | |
| `product.uso_enterrado` | "Sim" / "Não" | "Não" explícito vence a categoria |

## Armadilhas já pagas

- **Dado do produto fora do padrão quebra o gate em silêncio.** Um tanque verde
  não pegava a descrição porque tinha sido recriado com `productType "TANQUES"`
  e `vendor "Efizi"`. Quando uma página não renderiza, **compare os campos do
  produto com os irmãos dele** antes de mexer na regra — corrigir o dado é
  melhor que afrouxar o gate, porque afrouxar contamina outras marcas.
- **Chip com valor fixo mente.** "Garantia de 5 anos" estava escrito no template
  e aparecia em produto de 10 anos. Prefira ler o metafield.
- **Título com letra maiúscula engana parser.** O seletor de capacidade
  procurava a litragem por "palavra que contém L" e casava com "**L**impa",
  virando "i.mpaL". Parser de número exige que a palavra **comece com dígito**.
- **Manual gigante não vira asset.** O manual de polietileno da Fibromar tem
  269 MB; nesse caso a página fica sem bloco de download. Quando o manual traz o
  produto num apêndice, extraia só aquelas páginas com `pypdf` e suba o recorte.

## Referências

- `references/fabricantes.md` — spec por marca e por linha. **Leia antes de
  escrever spec** e atualize ao ler um manual novo.
- `references/deploy.md` — deploy no tema, verificação ao vivo e o bloqueio do
  tema publicado.
- `assets/template-descricao.liquid` — esqueleto do snippet.
- `scripts/upload-staged.py` — sobe o arquivo pro staged upload sem transcrever
  assinatura na mão.
