#!/usr/bin/env python3
"""
Envia um arquivo para o destino assinado devolvido por stagedUploadsCreate.

Existe pra evitar transcrever assinatura e policy na mão: essas strings têm
centenas de caracteres e um erro de cópia só aparece como HTTP 403 confuso.

Uso:
    python3 upload-staged.py <arquivo> <staged.json> [--index N]

O <staged.json> aceita qualquer um destes formatos:
  - a resposta inteira da mutation (com data.stagedUploadsCreate.stagedTargets)
  - a lista de stagedTargets
  - um único stagedTarget

Use --index quando pedir vários destinos numa mutation só (padrão: 0).
Também aceita o JSON por stdin, passando "-" no lugar do caminho.

Imprime o resourceUrl quando o upload dá certo (HTTP 201), que é o valor
para o body {type: URL, value: ...} do themeFilesUpsert.
"""

import argparse
import json
import subprocess
import sys


def carregar_target(caminho, indice):
    bruto = sys.stdin.read() if caminho == "-" else open(caminho, encoding="utf-8").read()
    dados = json.loads(bruto)

    # Desembrulha os formatos possíveis até chegar na lista de targets.
    if isinstance(dados, dict):
        if "data" in dados:
            dados = dados["data"]
        if "stagedUploadsCreate" in dados:
            dados = dados["stagedUploadsCreate"]
        if "stagedTargets" in dados:
            dados = dados["stagedTargets"]

    if isinstance(dados, dict):
        return dados
    if isinstance(dados, list):
        if not dados:
            sys.exit("erro: nenhum stagedTarget no JSON")
        if indice >= len(dados):
            sys.exit(f"erro: índice {indice} fora do intervalo ({len(dados)} destinos)")
        return dados[indice]
    sys.exit("erro: JSON não parece um stagedTarget")


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("arquivo", help="arquivo local a enviar")
    ap.add_argument("staged", help="JSON do stagedUploadsCreate (ou '-' para stdin)")
    ap.add_argument("--index", type=int, default=0, help="qual destino usar quando há vários")
    args = ap.parse_args()

    target = carregar_target(args.staged, args.index)
    url = target.get("url") or "https://shopify-staged-uploads.storage.googleapis.com/"
    parametros = target.get("parameters") or []
    resource_url = target.get("resourceUrl")

    if not parametros:
        sys.exit("erro: stagedTarget sem 'parameters' — confira o JSON")

    # A ordem importa: o arquivo tem que ser o último campo do multipart.
    cmd = ["curl", "-s", "-o", "/dev/null", "-w", "%{http_code}", "-X", "POST", url]
    for p in parametros:
        cmd += ["-F", f"{p['name']}={p['value']}"]
    cmd += ["-F", f"file=@{args.arquivo}"]

    resultado = subprocess.run(cmd, capture_output=True, text=True)
    codigo = resultado.stdout.strip()

    if codigo == "201":
        print(resource_url or "(sem resourceUrl no JSON)")
        return 0

    print(f"falhou: HTTP {codigo}", file=sys.stderr)
    if resultado.stderr:
        print(resultado.stderr, file=sys.stderr)
    return 1


if __name__ == "__main__":
    sys.exit(main())
