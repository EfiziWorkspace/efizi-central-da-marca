# Spec por fabricante

Tudo aqui saiu do manual/catálogo oficial da própria marca. **Não migre linha de
uma marca pra outra** — tampa, garantia e normas são justamente onde elas
divergem, e foi por copiar spec da Fortlev que produtos Fibromar e Acqualimp
foram ao ar descritos errado.

Ao ler um manual novo, acrescente ou corrija a linha aqui. Se um dado não estiver
no manual, deixe explicitamente como *não informado* em vez de preencher por
analogia.

---

## Vocabulário de tampa: use o mecanismo, não o nome do fabricante

Decisão do Guilherme (2026-07-29), depois de descobrir que **"tampa click"
significa coisas diferentes em cada marca**: na Fortlev é encaixe puro (empurra e
prende), na Acqualimp é encaixar e girar até travar. Publicar "click" fazia o
cliente que conhece uma marca esperar o mecanismo da outra.

Por isso o metafield `product.tipo_de_tampa` usa **três rótulos padronizados**,
descrevendo o que a peça faz, e não como o fabricante a batiza:

| Rótulo | Mecanismo | Onde está hoje |
|---|---|---|
| **Tampa de encaixe** | encaixa por pressão, não gira | caixas d'água Fortlev · Caixa Green+ Acqualimp |
| **Tampa roscável e trava com ¼ de volta** | encaixa e gira ¼ de volta até travar | tanques e cisternas Fortlev · Acqualimp inteira |
| **Tampa roscável** | rosqueia (giro não confirmado) | Fibromar |

Aplicado em 64 produtos. Ao cadastrar produto novo, use um desses três em vez de
copiar o nome comercial do catálogo.

⚠️ **Ponto a confirmar na Fibromar:** o manual dela diz "sistema de travamento de
tampas **por pressão**, dispensa a utilização de parafusos", o que descreveria
encaixe. O Guilherme, que vê a peça, diz que é roscável, e pediu o rótulo curto
por não ter certeza do ¼ de volta. Prevaleceu a observação dele; se um dia
alguém abrir essa discussão, o manual está do outro lado.

---

## Fortlev

**Reservatórios de água (linha Polietileno / Caixa d'Água)**
- Tampa: **roscável de ¼ de volta com travamento total**
- Flange: **já vem instalado** — 50 mm até 3.000 L, 60 mm de 5.000 a 20.000 L
- Proteção anti-UV
- Normas: **ABNT NBR 14799 / 15682**
- Garantia: **5 anos**
- Interligação em "U" pra somar capacidade
- Instalação: base rígida nivelada maior que o fundo, 60 cm livres ao redor,
  furação só com serra-copo

**Tanque Slim** (600 L) — água **de chuva**, não potável
- Acompanha separador de folhas; reduz até 60% do consumo de água potável
- NBR 15527 · garantia 5 anos · **não pode ser enterrado**

**Tanque Antibacteriano** (500 / 1.000 L, bege) — água **potável**
- Proteção antibacteriana **na própria parede** (aditivo no polietileno; age por
  contato, não sai com o tempo, não contamina a água)
- **Garantia 10 anos** (primeiro Fortlev com esse prazo, por rotomoldagem)
- Tampa ¼ de volta · flange instalado · compacto (altura reduzida)

**Leito de Secagem** — acessório do biodigestor/fossa
- Recebe o lodo descarregado; parte líquida drena e evapora, sólido seca
- Garantia **5 anos**
- Tem **tubulação de descompactação** (se o lodo compactar na entrada, desobstrui
  com haste)
- Destino do lodo seco: **aterro sanitário** ou neutralizar com cal e usar na
  agricultura, seguindo a **resolução CONAMA 375/2006**
- Atende biodigestores e fossas de **700, 750, 1.300 e 1.500 L/dia de qualquer
  fabricante**
- Dimensões (produto único): altura 80 cm, diâmetro do corpo 81 cm, boca 60 cm, 9 kg

**Tanque Industrial**
- Rotomoldado em polietileno **100% virgem**, tampa ¼ de volta, **alças de
  içamento**, pontos preparados pra furação
- Normas: **ABNT NBR 15762 · ASTM D543 / D1505 / D1998 · ISO 9001**
- Garantia **2 anos** · densidade até 1,3 g/ml (versão até 1,5 sob pedido)
- Combustível limitado a 10.000 L por norma · **não serve para água**

---

## Fibromar

**Tanque de Polietileno** (500 a 20.000 L; linhas comum e Prime)
- Tampa: **sistema de travamento por pressão** — dispensa parafusos.
  *Este é o erro clássico: não é ¼ de volta.*
- Polietileno **100% atóxico** com proteção anti-UV
- Normas: **ABNT NBR 14799 / 15682**
- Garantia: **5 anos**
- Flange: **acompanha as flanges** de entrada e saída (salvo se o cliente pedir
  sem furação) — até Ø50 mm de 500 a 2.500 L, Ø60 mm de 5.000 a 10.000 L,
  Ø110 mm no 20.000 L
- Instalação: base de **concreto pelo menos 15 cm maior** que o fundo, 60 cm
  livres ao redor, furação só nos painéis planos com furadeira e serra-copo
- Interligação possível; pra líquido que não seja água potável, consultar
  o fabricante
- Dimensões (diâmetro × altura, cm): 500 → 116×65 · 1.000 → 148×80 ·
  2.500 → 180×120 · 5.000 → 225×155 · 10.000 → 278×190 · 20.000 → 320×282

**Cisterna** — enterrada com contenção
- Polietileno 100% virgem, anti-UV, resistente e flexível
- **ABNT NBR 14799** · garantia **5 anos**
- Instalada enterrada com estrutura de contenção, por profissional

**Tanque Industrial**
- Polietileno de alta qualidade, **quimicamente inerte** (não reage com os
  líquidos permitidos)
- Densidades: **1,3 / 1,4 / 1,5 g/ml**
- Normas: **apenas "ABNT e ASTM"** — o manual **não cita códigos**, então não
  escreva NBR 15762 / ASTM D543 / ISO 9001 aqui
- Garantia **2 anos** · 100% atóxico com anti-UV
- Sem menção a alças de içamento ou tampa ¼ de volta
- Mesmas dimensões da linha de água

---

## Acqualimp

**Tanque (linha Azul)**
- Tampa **click com vedação total** (encaixa no aro e gira ~¼ de volta até
  travar) **+ tampa descentralizada**, que facilita a limpeza
- **Bases planas intermediárias → reserva técnica de incêndio** no mesmo
  reservatório (diferencial que nenhuma das outras tem)
- **Reforço na cúpula e alças de içamento**
- Normas: **ABNT NBR 14800 / 5626**
- Garantia: **10 anos**
- Flange: bases intermediárias e superiores até 100 mm, inferiores até 125 mm;
  tanques de 3.000 L até 60 mm
- Instalação: base lisa, plana, nivelada, com o fundo totalmente apoiado; nunca
  base gradeada, cruzetas, areia ou pedras; 60 cm livres ao redor; içar por
  **todas** as alças simultaneamente
- Limpeza sem escova de aço nem água sanitária
- Uso: **água potável**; para outras substâncias existe a linha Agro
- Dimensões (altura × diâmetro, cm): 3.000 → 119×188 · 5.000 → 138×244 ·
  7.500 → 219×222 · 10.000 → 194×282 · 15.000 → 248×306 · 20.000 → 282×322

**Cisterna** (3.000 / 5.000 / 10.000 L)
- Tampa click com vedação total · **tecnologia antibacteriana** · bases planas
  para conexões · alça de içamento · **PEAD de alta densidade** · acompanha
  **conexão de rosca 1" instalada**
- Garantia **10 anos** (não cobre dano de transporte, uso inadequado,
  negligência, acidente, reparo sem autorização, ou uso pra fim não indicado)
- **Nenhuma NBR é citada no manual de cisternas** e **não há menção a anti-UV**.
  Não migrar a NBR 14799 da cisterna Fibromar nem o anti-UV do tanque Acqualimp.
  O manual fala em PEAD, não em "matéria-prima 100% virgem"
- **Uso duplo**: água da rede pública **ou** captação de água de chuva (para
  fins secundários: lavagem, irrigação, descarga). Não afirma potabilidade
- Instalação enterrada, com exigências fortes: **não instalar onde o lençol
  freático fique acima da base** (mínimo 1,00 m do nível máximo em cheia) nem em
  mangue/local baixo que acumule água; teste de expansão do solo define o talude
  (>100% → A 2,25 m · 51-100% → 1,75 m · 26-50% → 1,25 m · 10-25% → 0,75 m ·
  <10% → cisterna + 0,25 m); material estabilizado = solo da escavação + 6% do
  peso em cimento; profundidade mínima = altura da cisterna + 0,20 m + espessura
  da base; base de **concreto armado** com malha eletrossoldada, 0,25 m maior que
  a cisterna ao redor (5 cm até 3.000 L, 10 cm de 5.000 a 10.000 L);
  encher de água antes do reaterro; compactar em camadas de 20 cm até o "ombro" e
  manter 48 h; laje de fechamento apoiada em solo natural, nunca sobre o reaterro
  nem sobre a cisterna; respiro pra troca de ar e área de inspeção; tráfego
  pesado exige laje de concreto armado dimensionada pelo responsável da obra
- Dimensões (altura × diâmetro, cm): 3.000 → 182×157 · 5.000 → 184×224 ·
  10.000 → 316×222 (variação de até 5 cm)
- Boca/tampa de **60 cm** nas três capacidades
- Peso vazia: 56,5 kg · 111,5 kg · 251,5 kg (cheia: 3.056,5 · 5.111,5 · 10.251,5)
- Acessórios de kit: filtro de água da chuva (até 200 m² de telhado, 9 L/s),
  freio d'água, sifão/ladrão, válvula de pé com crivo, eletroníveis, bomba

**Caixa d'Água com Filtro e Boia — linha "Água Limpa"** (500 a 2.500 L)
- Acompanha **Filtro Ponto de Entrada** + **Válvula Boia**
- Polietileno com **três camadas de proteção** e tampa click de vedação total,
  100% impermeável
- Garantia **10 anos** · água potável · não pode ser enterrada
- Limite honesto a declarar: o filtro **retém sujeira física** (folhas, areia,
  sedimento) e **não torna a água potável**

**Tanque +Green / Caixa Green+**
- Tampa click (gira ~¼ de volta até travar)
- Base deve exceder o diâmetro em pelo menos **10 cm**
- Empilhamento máximo: 3 unidades de 310 L, 2 unidades de 500 e 1.000 L
- Limpeza a cada 6 meses, sem produto químico ou objeto abrasivo
- **Garantia: não informada no manual** (o texto só diz "pelo prazo especificado
  neste guia") — confirmar com o usuário antes de publicar qualquer número

---

## Lacunas conhecidas

- **Acqualimp +Green**: prazo de garantia não consta no texto do manual.
- **Sultanques, Tecnipar, Luxtel, Aquarela**: sem manual lido; produtos dessas
  marcas caem na descrição simples do próprio produto (correta, sem página rica).
  Não escreva spec deles sem manual.
