# Deploy no tema e verificação

## Onde os arquivos moram

O repositório guarda a cópia versionada em `shopify/theme-edits/`
(`snippets/`, `sections/`, `assets/`). Edite ali primeiro e depois suba — assim
o repo continua sendo a fonte de verdade e dá pra ver o histórico.

## O bloqueio do tema publicado

A API **bloqueia `themeFilesUpsert` no tema publicado (role MAIN)**. É política
de servidor: não passa nem com autorização do usuário, e a mensagem fala em
"live storefront". Confira antes de começar um lote de edições:

```graphql
query { theme(id: "gid://shopify/OnlineStoreTheme/<id>") { name role } }
```

Se der `MAIN`, as opções são: trabalhar numa cópia despublicada e o usuário
publica depois; o usuário republicar o tema antigo por alguns minutos; ou
entregar o arquivo pro usuário colar no editor de código do admin (o editor do
admin **não** tem esse bloqueio — só a API tem).

**Metafields de produto e pedido continuam graváveis** com o tema publicado —
o bloqueio é só de arquivo de tema.

## O caminho rápido: staged upload

Mandar o conteúdo inline na mutation é lento pra arquivo grande (o
`main-product.liquid` tem ~170 KB). O caminho eficiente tem três passos:

**1. Pedir o destino**

```graphql
mutation stagedUploads($input: [StagedUploadInput!]!) {
  stagedUploadsCreate(input: $input) {
    stagedTargets { resourceUrl parameters { name value } }
    userErrors { field message }
  }
}
```

`resource: FILE`, `httpMethod: POST`, e `mimeType` `text/plain` para `.liquid`
ou `application/pdf` para manual. Dá pra pedir vários de uma vez.

**2. Enviar o arquivo** com `scripts/upload-staged.py`, que monta o multipart
com os parâmetros assinados. Transcrever assinatura e policy na mão funciona,
mas é onde erros de cópia aparecem:

```bash
python3 scripts/upload-staged.py caminho/do/arquivo.liquid staged.json
```

Espere HTTP **201**.

**3. Aplicar no tema** apontando pro `resourceUrl`:

```graphql
mutation upsert($themeId: ID!, $files: [OnlineStoreThemeFilesUpsertFileInput!]!) {
  themeFilesUpsert(themeId: $themeId, files: $files) {
    upsertedThemeFiles { filename }
    userErrors { filename code message }
  }
}
```

```json
{"filename": "snippets/efizi-descricao-x.liquid",
 "body": {"type": "URL", "value": "https://shopify-staged-uploads.../arquivo.liquid"}}
```

**O retorno vem com `upsertedThemeFiles` vazio mesmo quando dá certo.** Não
tente arrumar isso: confirme olhando `userErrors` (vazio = ok) e, principalmente,
abrindo a página.

Manual em PDF vai pra `assets/` pelo mesmo caminho e é referenciado com
`{{ 'manual-x.pdf' | file_url }}`.

## Verificar ao vivo

Abra a PDP no tema alvo e leia o texto renderizado:

```
https://efizi.com.br/products/<handle>?preview_theme_id=<id-do-tema>
```

Ler o texto da página (em vez de só tirar screenshot) é o que pega os erros de
conteúdo: marca errada, garantia errada, seletor embaralhado, bloco de manual
sobrando. Vale checar um produto **irmão** e um de **outra marca** pra confirmar
que o gate não vazou.

Quando o preview exigir sessão de admin, o link cru pode cair no tema publicado;
nesse caso confirme pelo rodapé do preview ou abra pelo admin.

## Notas de ambiente

- `pypdf` resolve extração e recorte de PDF (`pip install pypdf`). Manual com
  produto em apêndice: recorte só aquelas páginas antes de subir.
- PDF só-imagem não extrai texto — leia as páginas com o Read, que enxerga
  imagem.
- Páginas da loja com proteção podem bloquear execução de JavaScript pelo
  navegador; buscar o HTML com `curl` (inclusive com user-agent de robô) é uma
  alternativa boa pra inspecionar `og:`/JSON-LD.
