# Plataformas de envio — placeholders e regras

O mesmo casco serve pras três, mas cada uma preenche os dados de um jeito. Escolha a plataforma pelo destino do e-mail e troque só os placeholders dentro dos slots que você editou (header/footer/paleta ficam iguais).

## n8n (e-mails do Bling: NF-e, boleto, etc.)
- Placeholder: `{{ $json.campo }}` (expressão n8n). Ex.: `{{ $json.cliente_nome }}`, `{{ $json.link_danfe }}`, `{{ $json.valor_fmt }}`.
- O HTML vai no campo **HTML** do node **Send Email** como expressão (prefixo `=` na frente de todo o HTML quando setado via API).
- Fonte dos dados: banco da VPS (schema `staging`) e, quando o dado só existe na API do Bling (ex.: `linkBoleto`), um node HTTP busca. Ver memória `emails-bling-via-n8n-nfe`.
- Cuidado ao montar via SDK/JSON: minifique o HTML numa linha e use `JSON.dumps` pra escapar aspas; troque `font-family` com aspas simples por `Manrope,Arial,Helvetica,sans-serif` (sem aspas) pra evitar dor de escape.

## Shopify Notifications (transacionais da loja)
- Placeholder: **Liquid** da Shopify. Ex.: `{{ customer.first_name }}`, `{{ order_name }}`, `{{ order_status_url }}`, `{% for line in subtotal_line_items %}`, `{{ line | img_url: 'compact_cropped' }}`, `{{ total_price | money }}`, `{{ unsubscribe_url }}`.
- Cola no Admin → Configurações → Notificações → (a notificação) → Editar código. É colar à mão, sem API.
- Alguns templates EXIGEM o drop `{{ custom_message }}` solto no corpo (Lembrete de pagamento, Convite de conta, Contato com cliente) — sem ele dá "Erro ao recuperar a prévia".
- Carrinho/checkout abandonado = **Shopify Messaging** (Marketing → Automações), com variáveis próprias (`abandoned_checkout.line_items`, `abandoned_visit.products_added_to_cart`) e exige `{{ unsubscribe_url }}`.
- Ocultar transportadora: não usar `{{ shipping_method.title }}`; texto genérico ("Frete grátis para todo o Brasil"). Slogan do footer é o B2C.
- Detalhes e mapa arquivo→notificação: memória `emails-transacionais-shopify`.

## Bling (editor nativo) — ⚠️ NÃO montar casco custom aqui
- O editor de e-mail do Bling **bloqueia HTML custom** por "política de segurança": remove/reprova `<style>`, `@import` de fonte, `<!doctype>/<html>/<head>`, comentários MSO. Testado à exaustão — até trocar só cor de fundo é reprovado.
- Tags do Bling (quando o template nativo aceita): `[NOME_DESTINATARIO]`, `[NUMERO_PEDIDO]`, `[CHAVE_ACESSO]`, `[URL]`, `[LINK]`, `[VALOR]`, `[VENCIMENTO]`, `[LOGO_EMPRESA]`.
- **Conclusão:** e-mail branded do Bling **vai pelo n8n**, não pelo editor do Bling. Se insistir no Bling nativo, o máximo é fragmento de tabela com tudo inline, sem `<style>` (fica em Arial, sem responsivo) — e mesmo assim sem imagem externa (usar `[LOGO_EMPRESA]`).

## Saudação PF/PJ (vale pra qualquer plataforma que leia do banco)
Só personalize o primeiro nome quando for **pessoa física**. Pra empresa (PJ), a saudação sai **sem nome** — a razão social aparece só no bloco de dados. Assim evita "Olá, COMERCIAL LTDA!" e primeiros-tokens esquisitos de razão social.

No SQL (banco da VPS, `staging.clientes.tipo` = 'F' ou 'J'):
```sql
CASE WHEN c.tipo = 'F' AND COALESCE(c.nome, nf.contato_nome) <> ''
     THEN ', ' || initcap(split_part(COALESCE(c.nome, nf.contato_nome), ' ', 1))
     ELSE '' END AS saudacao
```
No H1: `...está pronta</span>{{ $json.saudacao }}.` → vira "..., Valdeci." (PF) ou "...." (PJ). O `initcap` normaliza nomes em CAIXA ALTA.
