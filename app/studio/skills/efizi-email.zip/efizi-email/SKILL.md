---
name: efizi-email
description: >-
  Monta e-mail TRANSACIONAL da Efizi no casco de marca — NF-e, boleto, pedido (confirmado, enviado,
  entregue), pagamento e redefinição de senha: e-mail disparado por um evento, isento de descadastro.
  Use SEMPRE que o pedido resultar num e-mail transacional que um cliente vai receber: "faz o e-mail
  de X", "monta a notificação de Y", "o e-mail do boleto/NF-e/pedido", "personaliza os e-mails
  transacionais", "cria o HTML do e-mail do pedido" — mesmo que não citem "Efizi" nem "casco". Cobre
  os três destinos: n8n (e-mails do Bling via banco), Shopify Notifications (Liquid) e Shopify Messaging.
  É a skill própria pra e-mail que a documento-html-efizi delega. NÃO use pra MARKETING / campanha /
  ciclo de vida (boas-vindas, carrinho abandonado, voltou ao estoque, winback, blast, newsletter →
  efizi-email-marketing), nem pra deck/painel/landing (documento-html-efizi), nem pra tema/PDP Shopify
  (efizi-pdp-descricao), nem pra montar o WORKFLOW n8n em si.
---

# E-mail da Efizi

Todo e-mail que um cliente da Efizi recebe usa o **mesmo casco de marca**. Esta skill existe pra você não redescobrir a marca a cada e-mail: o casco vem pronto, as regras de copy e de paleta estão fixadas, e o preview é um comando. Seu trabalho é adaptar o conteúdo — não reinventar a estrutura.

## Fluxo

1. **Descubra o destino** (muda só os placeholders, não o casco): n8n (e-mail do Bling), Shopify Notifications (Liquid) ou Shopify Messaging. Se não estiver claro, pergunte. Detalhes em [references/plataformas.md](references/plataformas.md).
2. **Duplique o casco**: copie `assets/casco.html` pro destino do projeto (ex.: `emails-n8n/<nome>.html`). Não comece do zero.
3. **Adapte só os slots marcados** no casco: preheader, eyebrow, H1, lede, CTA, bloco de dados, e as 2 frases do bloco de ajuda. Header, footer, paleta e estrutura ficam intocados — é o que dá consistência.
4. **Troque os placeholders** pela sintaxe da plataforma (`{{ $json.x }}`, Liquid ou `[TAG]`). Ver plataformas.md.
5. **Renderize o preview** e olhe de verdade (ver "Preview" abaixo). Sempre confira o visual antes de entregar.
6. **Entregue** o HTML + o PNG do preview. Se for pra memória/registro, siga o padrão do projeto.

## Regras de marca (o que faz parecer Efizi, não IA)

**Paleta** (uma cor de ênfase por peça — não encha de cor):
- Fundo creme `#F5F3EF` · card branco · ink `#0A0A0A` · texto secundário `#6B6660` / `#9A968F`
- Laranja `#FF4000` = ênfase/CTA (a cor da marca). Use no eyebrow, num único span do H1, e no botão.
- Verde `#1FA855` = só WhatsApp e economia/desconto. Amarelo `#FFD500` = só em faixa preta de PIX. Não misture.

**Tipografia**: Manrope (`@import` + fallback `Manrope,Arial,Helvetica,sans-serif`). Corpo ~18px — o público é 40+, texto pequeno afasta. H1 forte, 800.

**Copy** (isto é o que mais denuncia "e-mail de robô" — cuide):
- **Sem travessão** (—). Nunca. Reescreva a frase.
- Sem "Prezado", sem "Atenciosamente". Abra com nome+saudação natural, feche com "Obrigado".
- Sentence case, tom próximo e direto ("a gente resolve", "é só abrir"). Nada de formalidade empolada.
- Slogan do footer é o **B2C**: "O maior e-commerce de tratamento de água e esgoto do Brasil". (O B2B "plataforma de saneamento autônomo" NÃO vai em e-mail de cliente.)

**Bloco de ajuda** (fixo no casco): WhatsApp verde (`wa.me/551140039921`) + "Ligar pra gente" contornado (`tel:+551141170660`). Edite só as 2 frases de cima; canais e números não mudam.

**Saudação PF vs PJ**: só personalize o primeiro nome pra **pessoa física**. Empresa (PJ) sai **sem nome** na saudação (a razão social aparece no bloco de dados). Ver o `CASE ... saudacao` em plataformas.md. Isso evita "Olá, TRANSPORTES XYZ LTDA!" e tokens truncados feios.

## Preview

Os placeholders aparecem como texto cru, então pra um preview realista preencha valores de exemplo numa cópia temporária e renderize essa:

```bash
sed -E 's/\{\{ \$json\.cliente_nome \}\}/Valdeci Jose de Souza/g; s/\{\{ \$json\.valor_fmt \}\}/R$ 2.128,00/g' \
  emails-n8n/nome.html > /tmp/preview.html
bash ~/.claude/skills/efizi-email/scripts/preview.sh /tmp/preview.html /tmp/preview.png
```

Depois **leia o PNG** (`/tmp/preview.png`) e confira: acento laranja num lugar só, nada de travessão, saudação certa (PF com nome / PJ sem), botão e dados legíveis. O `preview.sh` acha o Chrome sozinho.

## Referências reais no repo (copie a lógica, não do zero)
- `emails-n8n/nota-fiscal-emitida.html` — NF-e via n8n, com saudação PF/PJ. É o casco "canônico".
- `emails-n8n/boleto-disponivel.html` — boleto (bloco de dados enxuto: Cliente/Valor/Vencimento).
- `shopify/notifications/*.html` — kit transacional da Shopify em Liquid (pedido, enviado, entregue, pagamento, etc.), com trilha de progresso e variantes.

## Erros que já custaram tempo (não repita)
- **Não tente colar casco custom no editor nativo do Bling** — ele bloqueia `<style>`/`@import`/doctype por segurança. E-mail branded do Bling vai pelo **n8n**. (plataformas.md)
- **Escape ao montar via n8n SDK/JSON**: minifique o HTML numa linha, use `JSON.dumps`, e tire as aspas simples do `font-family`.
- **Comentário SQL inline** (`-- ...`) some numa query de uma linha só e comenta o resto — tire antes de minificar.
- **Teste seguro**: pra testar envio real, aponte o "To" pro seu e-mail e reverta depois; nunca dispare teste pro cliente.
