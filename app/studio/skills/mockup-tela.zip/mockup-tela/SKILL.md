---
name: mockup-tela
description: >
  Compõe um print de site/página na TELA de um dispositivo (notebook, monitor,
  celular) dentro de uma cena fotorreal na cara da Efizi (padrão capa dourada),
  via Nano Banana Pro (CLI Higgsfield). Use SEMPRE que o pedido for pôr um
  site/página/print "na tela do PC/notebook/monitor/celular" de uma imagem,
  "mockup de tela com o site", "imagem de um dispositivo com a home aberta",
  "capa/login/peça com o site na tela", "coloca esse print na tela" — mesmo sem
  citar Nano Banana. NÃO use para gerar imagem SEM tela de dispositivo (skill
  higgsfield-generate), nem para foto de produto (higgsfield-product-photoshoot),
  nem pra montar HTML (documento-html-efizi).
---

# Mockup de tela (site na tela do dispositivo) — Efizi

Objetivo: uma imagem fotorreal onde a **tela de um dispositivo mostra o site/página
real** (o print de verdade, não texto inventado pela IA), dentro de uma cena na
cara da Efizi. Serve pra login, capa de apresentação, peça, hero de LP.

## Regra de ouro
**Sempre via Nano Banana Pro** passando 2 imagens (cena + print). **NUNCA** colar o
print na mão (perspectiva em PIL): fica flutuando, chapado e sem brilho de tela.
O Nano Banana reacende a tela, ajusta perspectiva, reflexo e luz.

## Pré-voo (uma vez)
- CLI: `command -v higgsfield` (fica em `~/.npm-global/bin/higgsfield`). Se pedir
  login, avisar o usuário (não manuseio credencial).
- Modelo: `nano_banana_2` (Nano Banana Pro). Param `input_images` é array → passar
  `--image` duas vezes (aceita caminho local, faz upload sozinho).

## Passos

### 1. Obter a CENA (imagem com o dispositivo)
- Se o usuário deu a imagem, usar.
- Se não, gerar via Nano Banana no **padrão capa dourada da Efizi** (ref:
  `apresentacao-reposicionamento/img/ato1-virada.jpg`). A tela precisa estar
  **levemente virada, nítida, com espaço escuro pra headline** se for login/capa.
  Estilo-base: `warm golden-hour cinematic light, film look, Brazilian countryside
  of a well-established small/medium rural producer (prosperous, tidy, NOT humble),
  premium editorial photography, 16:9, generous darker negative space for a headline`.
  Ver [[feedback-geracao-imagem-higgsfield]] (Nano Banana Pro, hero nítido sem DOF).

### 2. Obter o PRINT (o que vai na tela)
- Arquivo → usar direto.
- URL ao vivo (ex.: `efizi.com.br`) → capturar com Chrome headless:
  `--headless=new --hide-scrollbars --window-size=1920,1080 --virtual-time-budget=9000 --screenshot`.
  ⚠️ **Fechar modais** (ex.: popup "Informe sua região" da Efizi) antes — se travar,
  usar o print que o usuário mandou.
- Print colado pelo usuário → procurar na mesa: `~/Desktop/Captura de Tela *.png`
  (o mais recente).

### 3. Compor (o passo que importa)
```bash
PROMPT="Take the FIRST image (a scene with a device) and replace ONLY the website/content shown on the device screen with the SECOND image. Keep the exact same scene, device, lighting, shadows and composition completely unchanged. The content must fill the screen edge to edge with correct perspective matching the tilted screen, realistic screen brightness and subtle screen glare. Photorealistic, high detail, do not alter anything except the screen content."
higgsfield generate create nano_banana_2 \
  --image CENA.png --image PRINT.png \
  --aspect_ratio 16:9 --resolution 2k \
  --prompt "$PROMPT" --wait --wait-timeout 8m --wait-interval 6s
```
Baixar a URL retornada (`curl -o`).

### 4. Conferir (sempre)
Abrir o resultado e checar: a tela **encaixou** (sem sobra do site antigo, sem
filete/faixa nas bordas), sem "flutuar". Se sobrar site antigo ou vazar, reforçar
no prompt: *"the website must FULLY cover the screen, edge to edge, no old content
visible"* e regerar.

### 5. Otimizar (se for fundo de página/site)
Resize ~1920px de largura, JPG q88 (~300–400KB) — fundo não precisa de 2752px.

## Guardrails aprendidos
- **2k é o padrão.** 4k **não** conserta texto miúdo — só deixa o "gibberish" da
  IA mais nítido (pior pra fundo). Use 4k só pra impressão grande onde a letra
  pequena do print não importa.
- O **hero/título grande** do print sai nítido; **textos miúdos** a IA reinventa
  (levemente embolados) — aceitável em fundo, ninguém lê de longe.
- Se o download local falhar, o job existe no Higgsfield: recuperar por
  `higgsfield generate list --image --json` → casar pelo `prompt` → `result_url`.
- Produto na tela = **site real** (print), nunca inventar. Alinha com
  [[feedback-pecas-hibrido-ia-tipografia]] (IA gera imagem; conteúdo é real).

## Relacionadas
- `higgsfield-generate` — geração genérica (sem tela de dispositivo).
- [[central-da-marca-hub]] — a tela de login da Central usa exatamente esse fluxo
  (cena v08 + print `efizi.com.br` → `v08-nano-web.jpg`).
