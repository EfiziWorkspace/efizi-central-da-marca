---
name: dashboard-tv-efizi
description: >
  Cria ou altera dashboards/TVs operacionais da Efizi (Command Center) no
  formato aprovado em 2026-08-03. Use SEMPRE que o pedido envolver painel de
  TV, tela da sala, dashboard operacional ao vivo, "tela pro time", régua de
  atrasados, tendência de fila, ou mudanças nas rotas /tv/* do
  efizi-command-center. NÃO use para documento HTML avulso (documento-html-efizi)
  nem para deck (efizi-apresentacoes).
---

# Dashboard de TV da Efizi

O formato foi fechado com o Gui em 2026-08-03 depois de ~10 iterações ao vivo.
Estas regras NÃO são sugestões de estilo — cada uma corrigiu um erro real que
o time apontou na parede. Mudar uma regra = conversar com o Gui antes.

## Princípios (a alma do painel)

1. **Pessoa → ação → tempo.** TV/briefing operacional diz QUEM faz O QUÊ e há
   quanto tempo espera. Diagnóstico e estatística são conversa de gestão.
   Bloco de pessoa = UMA frase imperativa em linguagem falada ("Ligue pra
   transportadora e confirme as 4 coletas") + um número grande.
2. **Número colorido conta coisa daquela cor.** Sempre `X vencidos`(cor)
   `/total`(neutro). NUNCA pintar um total pela idade do pior card — "25 em
   vermelho" fez parecer que os 25 estavam atrasados.
3. **Operação ≠ gestão, nunca na mesma tela.** Operação = missões + faixa % no
   topo. Gestão = placar, etapas, alarme, clientes. Misturar foi o "estranho"
   que travou o formato por uma tarde.
4. **Paleta V2 "semáforo calibrado"** (2026-08-04, contra o "tudo vermelho
   banaliza"): VERMELHO só pro crítico — parado 7d+, sem resposta 24h+, alarme
   ⚡ e etapa que contém parado. Vencido comum, fluxo e clientes esperando =
   ÂMBAR. Neon SÓ no alarme (pulsante, keyframes `tv-pisca`) e nos verdes;
   vermelho comum é risco chapado. Alarme some sozinho ao zerar.
5. **Glossário fechado (língua do time):** *vencido* = passou o prazo da etapa
   OU a data combinada · *parado há 7+ dias* = fura a fila · *vitória* = dívida
   morta (parado/sem-resposta resolvido; card novo fechado NÃO conta) ·
   *na fila* = neutro. Vetados: "travado", "podre", "atacado", "a bola".
6. **Data combinada manda.** Etapa com data-alvo (mapa `DATA_ALVO`, espelho do
   `DATE_SLA_STAGES` do CRM) é julgada pela DATA: futura = agendado (em dia,
   não é parado), passada = vencido. Validar valor com regex de data — campo
   reusado traz lixo ("nao").
7. **Sem dinheiro na TV** (pedido de 2026-08-03). Sem R$, sem valor de carteira.
8. **Cliente = "Nome S." + código.** Nunca nome completo/CPF/telefone. Sem
   casamento no data-lake → só o código, nunca inventa.
9. **Dias corridos**, declarado na legenda (o CRM usa horas úteis — divergência
   conhecida e proposital).
10. **Celebração honesta.** Vitória só quando dívida morta morre. Régua "Em
    dia" veste a cor do próprio valor (≥80 ok · ≥50 warn · crit).
11. **TV nunca mostra número velho.** Fonte caiu → tela de erro que volta
    sozinha. Sem cache, sem cópia, `force-dynamic`.

## Arquitetura (espelho por construção)

- **Uma fonte:** `src/lib/tv-crm.ts` (pool `crm-db.ts`, usuário `tv_readonly`,
  pooler **aws-1**-sa-east-1 — aws-0 dá "tenant not found").
- **Componentes compartilhados:** `TelaOperacao`/`TelaGestao`/`TelaTendencia`
  em `src/app/tv/_components/`. TODAS as rotas (`/tv/td`, `/tv/ocorrencias`,
  `/tv/parede`, `/tv/tendencia`) renderizam os MESMOS componentes — alterar um
  altera todas as telas (fiscal, sala, avulsa). Nunca duplicar tela.
- **Rotação:** `TvScreens.tsx` — relógio (`Date.now() % ciclo`, tick 100ms),
  crossfade 400ms, P pausa via BroadcastChannel `'tv-efizi'`, ←/→ trocam,
  F/2-cliques = tela cheia. Modo parede: `?papel=operacao|gestao`, o FUNIL
  alterna sincronizado; 3ª tela (tendência) roda nos dois papéis juntos.
- **CSS:** `src/app/tv/tv.css`, unidades vh/vw, escuro comprometido. Bordas de
  cartão = `var(--tv-linha)` = `max(2px, 0.22vh)` — 1px treme na TV.
- **Números do pg chegam como STRING** (`extract`, `numeric`) — cast `::float8`
  no SQL e `Number()` no formatador, senão `.toFixed` derruba a tela.
- **Tendência:** série reconstruída de `return_activities.stage_changed`
  (existe desde 2026-06-10); eixo X = união das datas (dia sem fila quebra a
  linha, não vira 0%); limitação declarada na legenda.
- **Rotas curtas = o que a TV mostra:** `/tv/log1` renderiza GESTÃO e
  `/tv/log2` OPERAÇÃO (invertidos a pedido em 2026-08-04 — pra trocar painéis
  de TVs já instaladas, inverta o CONTEÚDO da rota, não os aparelhos);
  `/tv/fiscal` = CTD do fiscal (`/tv/td` redireciona).

## TVs físicas: instalação, identidade e controle remoto

- **Registros:** painéis em `src/lib/tvs.ts` (TVS); TVs físicas em
  `src/lib/tvs-registro.ts` (TVS_FISICAS) — módulo PURO, o proxy edge importa
  e não pode carregar o driver do Postgres. TV nova = uma entrada + deploy.
- **Instalação sem senha:** `tv.efizi.app/<codigo>` (código curto por TV, com
  sufixo aleatório revogável no registro) → o proxy redireciona pro link
  completo: painel padrão + `?tv=<id>` + `?chave=` (TV_CHAVE no .env, única e
  revogável). A chave vira cookie httpOnly de 1 ano e SOME da URL. Vale só
  nas rotas /tv/* — o app continua atrás do login Google.
- **Identidade pareada no APARELHO, não na URL** (furo real: URL da log1 em
  outra TV mentia): o `?tv=` semeia sessionStorage (por aba — a parede tem 2
  TVs no MESMO Chrome) com fallback localStorage. `?tv=off` despareia.
- **Telemetria:** cada /tv/* aberta pulsa a cada 30s (POST /api/tv/pulso) →
  `public.tv_pulsos` no Supabase do CRM (em memória FALHOU: cada servidor um
  estado). Escrita via `escreverTelemetria` (transação read-write explícita
  do tv_readonly — exceção única). Dash TVs (`/areas/tecnologia/tvs`) mostra
  bolinha ao vivo (pulso <90s), "exibindo X" e "passando em qual TV".
- **Troca remota:** dropdown no card grava o desejado em `public.tv_comandos`;
  o pulso devolve e a TV navega sozinha (≤30s). Server action valida área +
  inventário + catálogo.
- **Tela cheia:** fullscreen automático é bloqueado pelo navegador — clique em
  QUALQUER lugar entra (botão verde central instrui); ESC sai.
- ⚠️ Nunca logar `redirect_url` de curl nas rotas com chave — vaza a TV_CHAVE
  no transcript (já aconteceu; rotacionada na hora).

## Loop de trabalho (obrigatório)

Aplicar → **julgar você mesmo** (DOM via Chrome + recontagem SQL independente)
→ corrigir → `tsc --noEmit` + eslint → commit semântico + push. Nunca declarar
pronto sem ver a tela renderizada e os números baterem com o banco por um
caminho independente.

## Deploy

VPS Hostinger `31.97.24.124` (`root`, chave `~/.ssh/id_ed25519`), padrão da
casa: build `standalone` local → copiar `.next/static` e `public` pra dentro →
rsync pra `/var/www/command-center` → `.env` no diretório (Next lê sozinho;
PORT/HOSTNAME vão no ambiente do PM2, não no .env) → PM2 `command-center`
porta **3070** (127.0.0.1) → nginx `command-efizi.conf` (+ `tv-efizi.conf` pro
tv.efizi.app) → certbot após DNS. DNS = Cloudflare, zona efizi.app (dá pra
criar registro pela sessão do Gui no Chrome: A · nome · 31.97.24.124 · nuvem
CINZA). Auth = Google OAuth no Supabase do CRM (`fiwodtzraqzcqyyfzqcf`) —
domínio novo entra nos Redirect URLs E na allowlist ALLOWED_FORWARDED_HOSTS
de `src/lib/request-origin.ts` (sem ela o callback redireciona pro host
interno localhost:3070).

## Checklist final

- [ ] Regras 1–11 respeitadas (em especial: vermelho chapado, X/total, sem R$)
- [ ] Mudança feita nos componentes compartilhados, não numa rota só
- [ ] Números validados por SQL independente
- [ ] Tela vista renderizada (Chrome) antes de declarar pronto
- [ ] Commit + push; se afetar produção, rebuild + rsync + pm2 restart
- [ ] PROJECT_LOG atualizado só quando o Gui pedir
