---
name: dashboard-tv-efizi
description: >
  Cria ou altera dashboards/TVs operacionais da Efizi (Command Center) no
  formato aprovado em 2026-08-03. Use SEMPRE que o pedido envolver painel de
  TV, tela da sala, dashboard operacional ao vivo, "tela pro time", régua de
  atrasados, tendência de fila, ou mudanças nas rotas /tv/* do
  efizi-command-center. NÃO use para documento HTML avulso (documento-html-efizi)
  nem para deck (efizi-apresentacoes).
---

# Dashboard de TV da Efizi

O formato foi fechado com o Gui em 2026-08-03 depois de ~10 iterações ao vivo.
Estas regras NÃO são sugestões de estilo — cada uma corrigiu um erro real que
o time apontou na parede. Mudar uma regra = conversar com o Gui antes.

## Princípios (a alma do painel)

1. **Pessoa → ação → tempo.** TV/briefing operacional diz QUEM faz O QUÊ e há
   quanto tempo espera. Diagnóstico e estatística são conversa de gestão.
   Bloco de pessoa = UMA frase imperativa em linguagem falada ("Ligue pra
   transportadora e confirme as 4 coletas") + um número grande.
2. **Número colorido conta coisa daquela cor.** Sempre `X vencidos`(cor)
   `/total`(neutro). NUNCA pintar um total pela idade do pior card — "25 em
   vermelho" fez parecer que os 25 estavam atrasados.
3. **Operação ≠ gestão, nunca na mesma tela.** Operação = missões + faixa % no
   topo. Gestão = placar, etapas, alarme, clientes. Misturar foi o "estranho"
   que travou o formato por uma tarde.
4. **Paleta V2 "semáforo calibrado"** (2026-08-04, contra o "tudo vermelho
   banaliza"): VERMELHO só pro crítico — parado 7d+, sem resposta 24h+, alarme
   ⚡ e etapa que contém parado. Vencido comum, fluxo e clientes esperando =
   ÂMBAR. Neon SÓ no alarme (pulsante, keyframes `tv-pisca`) e nos verdes;
   vermelho comum é risco chapado. Alarme some sozinho ao zerar.
5. **Glossário fechado (língua do time):** *vencido* = passou o prazo da etapa
   OU a data combinada · *parado há 7+ dias* = fura a fila · *vitória* = dívida
   morta (parado/sem-resposta resolvido; card novo fechado NÃO conta) ·
   *na fila* = neutro. Vetados: "travado", "podre", "atacado", "a bola".
6. **Data combinada manda.** Etapa com data-alvo (mapa `DATA_ALVO`, espelho do
   `DATE_SLA_STAGES` do CRM) é julgada pela DATA: futura = agendado (em dia,
   não é parado), passada = vencido. Validar valor com regex de data — campo
   reusado traz lixo ("nao").
7. **Sem dinheiro na TV** (pedido de 2026-08-03). Sem R$, sem valor de carteira.
8. **Cliente = "Nome S." + código.** Nunca nome completo/CPF/telefone. Sem
   casamento no data-lake → só o código, nunca inventa.
9. **Dias corridos**, declarado na legenda (o CRM usa horas úteis — divergência
   conhecida e proposital).
10. **Celebração honesta.** Vitória só quando dívida morta morre. Régua "Em
    dia" veste a cor do próprio valor (≥80 ok · ≥50 warn · crit).
11. **TV nunca mostra número velho.** Fonte caiu → tela de erro que volta
    sozinha. Sem cache, sem cópia, `force-dynamic`.

## Arquitetura (espelho por construção)

- **Uma fonte:** `src/lib/tv-crm.ts` (pool `crm-db.ts`, usuário `tv_readonly`,
  pooler **aws-1**-sa-east-1 — aws-0 dá "tenant not found").
- **Componentes compartilhados:** `TelaOperacao`/`TelaGestao`/`TelaTendencia`
  em `src/app/tv/_components/`. TODAS as rotas (`/tv/td`, `/tv/ocorrencias`,
  `/tv/parede`, `/tv/tendencia`) renderizam os MESMOS componentes — alterar um
  altera todas as telas (fiscal, sala, avulsa). Nunca duplicar tela.
- **Rotação:** `TvScreens.tsx` — relógio (`Date.now() % ciclo`, tick 100ms),
  crossfade 400ms, P pausa via BroadcastChannel `'tv-efizi'`, ←/→ trocam,
  F/2-cliques = tela cheia. Modo parede: `?papel=operacao|gestao`, o FUNIL
  alterna sincronizado; 3ª tela (tendência) roda nos dois papéis juntos.
- **CSS:** `src/app/tv/tv.css`, unidades vh/vw, escuro comprometido. Bordas de
  cartão = `var(--tv-linha)` = `max(2px, 0.22vh)` — 1px treme na TV.
- **Números do pg chegam como STRING** (`extract`, `numeric`) — cast `::float8`
  no SQL e `Number()` no formatador, senão `.toFixed` derruba a tela.
- **Tendência:** série reconstruída de `return_activities.stage_changed`
  (existe desde 2026-06-10); eixo X = união das datas (dia sem fila quebra a
  linha, não vira 0%); limitação declarada na legenda.
- **Rotas curtas = o que a TV mostra:** `/tv/log1` renderiza GESTÃO e
  `/tv/log2` OPERAÇÃO (invertidos a pedido em 2026-08-04 — pra trocar painéis
  de TVs já instaladas, inverta o CONTEÚDO da rota, não os aparelhos);
  `/tv/fiscal` = CTD do fiscal (`/tv/td` redireciona).

## TVs físicas: instalação, identidade e controle remoto

- **Registros:** painéis em `src/lib/tvs.ts` (TVS); TVs físicas em
  `src/lib/tvs-registro.ts` (TVS_FISICAS) — módulo PURO, o proxy edge importa
  e não pode carregar o driver do Postgres. TV nova = uma entrada + deploy.
- **Instalação sem senha:** `tv.efizi.app/<codigo>` (código curto por TV, com
  sufixo aleatório revogável no registro) → o proxy redireciona pro link
  completo: painel padrão + `?tv=<id>` + `?chave=` (TV_CHAVE no .env, única e
  revogável). A chave vira cookie httpOnly de 1 ano e SOME da URL. Vale só
  nas rotas /tv/* — o app continua atrás do login Google.
- **Identidade pareada no APARELHO, não na URL** (furo real: URL da log1 em
  outra TV mentia): o `?tv=` semeia sessionStorage (por aba — a parede tem 2
  TVs no MESMO Chrome) com fallback localStorage. `?tv=off` despareia.
- **Telemetria:** cada /tv/* aberta pulsa a cada 30s (POST /api/tv/pulso) →
  `tv_pulsos` no banco PRÓPRIO do app (em memória FALHOU: cada servidor um
  estado). Dash TVs (`/areas/tecnologia/tvs`) mostra bolinha ao vivo (pulso
  <90s), "exibindo X" e "passando em qual TV". O pulso carrega um `diag` com
  tela cheia, vídeo da vigília e veredito do som — **é ele que resolve bug de
  TV**; sem isso "às vezes não funciona" não vira diagnóstico.
- **Troca remota:** dropdown no card grava o desejado em `tv_comandos`; o pulso
  devolve e a TV navega sozinha (≤30s). ⚠️ A comparação é **caminho + query**:
  só pathname não remove parâmetro já grudado na URL, e um `?buzina=teste`
  fica preso repetindo a cada recarga.
- **Casco `/tv-shell`:** a TV carrega o CASCO, não o painel direto. Ele é dono
  da tela cheia e o painel roda num iframe — deploy e troca de painel
  recarregam só o iframe, então ninguém vai de TV em TV clicar de novo.
  Consequência: `/tv/*` responde `X-Frame-Options: SAMEORIGIN` (o resto do app
  segue `DENY`). Esquecer isso derruba TODAS as telas com
  `ERR_BLOCKED_BY_RESPONSE` — já aconteceu.
- **Autocura:** vigia do casco a cada 20s procura a MARCA do painel
  (`.tv-page`), não "tem conteúdo" — página de erro do nginx TEM conteúdo e
  passava por viva. Confirma que o servidor responde antes de recarregar
  (durante deploy, insistir só troca um erro por outro). Auto-reload por versão
  no pulso leva código novo às telas em ≤30s.
- **Tela cheia:** o navegador exige gesto humano, sem exceção. Vale QUALQUER
  tecla do controle, não só clique — e o casco precisa de `window.focus()`, ou
  o foco nasce no iframe e a TV "não responde ao controle".
- **Som na TV:** vai por `<video>` com mp4, NUNCA por `<audio>` — na LG
  (webOS 23) o `<audio>` resolve o `play()` e sai calado. O mp4 precisa de
  dimensão e taxa convencionais (640×360, 24 fps): 64×64 dá
  `NotSupportedError`, mesmo o vídeo ocupando 4px na tela. Esperar o `canplay`
  antes de tocar, senão `AbortError` cai no plano B e o som que sai é o errado.
- **Mídia estática tem nome versionado** (`buzina-ar-v2.mp4`): trocar conteúdo
  mantendo o nome faz a TV servir o arquivo velho do cache. E toda mídia fica
  FORA do gate no matcher do proxy, senão vira redirect de login e nunca toca.
- **Comemoração ("parede limpa") se decide no SERVIDOR**, nunca em cada tela:
  por tela não há cota possível e a sala ouve dobrado (já aconteceu — 5 TVs
  juntas). Estado único numa tabela; regras calibradas: uma por dia por funil,
  verde sustentado ~2 min (mata oscilação na origem), só em expediente. Som só
  na "voz da sala" (lista no registro); cartão em todas.
- ⚠️ Nunca logar `redirect_url` de curl nas rotas com chave — vaza a TV_CHAVE
  no transcript (já aconteceu; rotacionada na hora).
- ⚠️ **Rotação de chave usa `TV_CHAVE_ANTIGA`**: o cookie vale com a vigente OU
  a antiga, senão a rotação derruba TV instalada.
- ⚠️ **Perguntar ANTES de testar em TV** (buzina, troca de painel, deploy): a
  sala está trabalhando. Diagnóstico que não toca na tela é livre.

## Painel novo herda quase tudo

Passe SEMPRE pelo `TvScreens`, mesmo com uma tela só (`telas={[<X/>]}`) — é ele
que traz os avisos e a comemoração. Do layout de `/tv` vêm de graça: crachá,
casco em tela cheia, vigília anti-repouso, telemetria, auto-reload e troca
remota. A página só DECLARA o que é verde pra ela (`avaliarBuzina` → repassa a
celebração). Paleta e tipografia valem pra quem usa as classes do `tv.css`.

## Loop de trabalho (obrigatório)

Aplicar → **julgar você mesmo** (DOM via Chrome + recontagem SQL independente)
→ corrigir → `tsc --noEmit` + eslint → commit semântico + push. Nunca declarar
pronto sem ver a tela renderizada e os números baterem com o banco por um
caminho independente.

## Deploy

**Clone e build NA VPS** (mudou em 05/08/2026; build local + rsync morreu):
`ssh root@31.97.24.124` → `cd /var/www/command-center && git pull && ./deploy.sh`.
O script instala com `npm ci`, builda, copia `.next/static` e `public` pra
dentro do standalone, copia o `.env` da raiz e sobe.

- **Cluster de 2 + `pm2 reload`**, nunca `restart`: o reload troca as instâncias
  uma a uma e o domínio não cai. Com restart havia segundos de 502 a cada
  deploy — e a TV ficava travada no erro. Só é seguro porque **não há estado em
  memória**: fila, trilha e telemetria vivem no banco.
- ⚠️ Se o PM2 apontar pro `server.js` da RAIZ (herança do rsync), o deploy roda
  e **não surte efeito** — o build novo fica em `.next/standalone`. Conferir com
  `pm2 describe`; corrigir recriando o processo lá dentro.
- ⚠️ **O `.env` da VPS é insubstituível e não está no git.** Já foi sobrescrito
  pelo `.env.example` num deploy e as 5 TVs foram pro login (sem `TV_CHAVE` o
  crachá não vale). Fazer backup antes de mexer; conferir a lista de chaves
  depois.
- PORT/HOSTNAME vão no ambiente do PM2, não no `.env`. nginx
  `command-efizi.conf` (+ `tv-efizi.conf`), certbot após DNS. DNS = Cloudflare,
  zona efizi.app (A · nome · 31.97.24.124 · nuvem CINZA).
- Auth = Google OAuth no Supabase do CRM — domínio novo entra nos Redirect URLs
  E na allowlist `ALLOWED_FORWARDED_HOSTS` de `src/lib/request-origin.ts`.
- ⚠️ **Rebase antes de deploy: olhar o que veio junto.** Commit de outra pessoa
  pode exigir variável nova; o build passa e quebra em runtime (já derrubou a
  telemetria por 3 horas).

## Checklist final

- [ ] Regras 1–11 respeitadas (em especial: vermelho chapado, X/total, sem R$)
- [ ] Mudança feita nos componentes compartilhados, não numa rota só
- [ ] Números validados por SQL independente
- [ ] Tela vista renderizada (Chrome) antes de declarar pronto
- [ ] Commit + push; se afetar produção, `git pull && ./deploy.sh` NA VPS
- [ ] Mexeu em TV? Perguntar antes de testar — e conferir o `diag` do pulso
      depois (tela cheia, vídeo, som), não só olhar a parede
- [ ] PROJECT_LOG atualizado só quando o Gui pedir
