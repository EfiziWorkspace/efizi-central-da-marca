#!/usr/bin/env python3
"""Verifica um documento HTML da Efizi antes de entregar.

  verificar.py arquivo.html [--afirma "45 itens" ...]

Checa fonte embutida, offline, contraste sobre cor de marca, tabela larga com
rolagem própria, acentuação e coerência dos números que o documento afirma.
Sai com código 1 se algo reprovar.
"""
import argparse, pathlib, re, sys
from collections import Counter

def lin(c):
    c/=255
    return c/12.92 if c<=.03928 else ((c+.055)/1.055)**2.4
def lum(rgb): 
    r,g,b=rgb; return .2126*lin(r)+.7152*lin(g)+.0722*lin(b)
def contraste(a,b):
    la,lb=lum(a),lum(b); hi,lo=max(la,lb),min(la,lb)
    return (hi+.05)/(lo+.05)
def hexa(h):
    h=h.lstrip('#')
    return tuple(int(h[i:i+2],16) for i in (0,2,4))

MARCA = {'laranja':'#FF4000','amarelo':'#FFD500'}

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("arquivo")
    ap.add_argument("--afirma",action="append",default=[],
                    help='alegação a conferir, ex: "45 itens"')
    a=ap.parse_args()
    h=pathlib.Path(a.arquivo).read_text()
    falhas=[]; avisos=[]

    def ok(nome,cond,detalhe=""):
        print(("  OK    " if cond else "  FALHA ")+nome+(f"  · {detalhe}" if detalhe else ""))
        if not cond: falhas.append(nome)

    print(f"\n=== {pathlib.Path(a.arquivo).name} ===\n")

    # fonte
    ok("sem placeholder de fonte", "@@FONT" not in h)
    ok("Manrope embutida (3 pesos)", h.count("data:font/woff2;base64,")==3,
       f"{h.count('data:font/woff2;base64,')} encontradas")

    # offline
    # só conta o que a PÁGINA CARREGA. <a href> externo é navegação, não quebra offline.
    ext  = re.findall(r'<script[^>]+src="https?://[^"]+"',h)
    ext += re.findall(r'<img[^>]+src="https?://[^"]+"',h)
    ext += re.findall(r'<iframe[^>]+src="https?://[^"]+"',h)
    ext += re.findall(r'<link[^>]+href="https?://[^"]+"',h)
    ext += re.findall(r'@import\s+url\(["\']?https?://',h)
    ext += re.findall(r'url\(["\']?https?://[^)]+\)',h)
    ok("100% offline (nada carregado de fora)", not ext, f"{len(ext)} recursos externos" if ext else "")
    links=len(re.findall(r'<a[^>]+href="https?://',h))
    if links: print(f"  nota    {links} link(s) externo(s) de navegação — ok, não afeta o offline")

    # contraste sobre cor de marca
    branco=hexa('#FFFFFF')
    for nome,cor in MARCA.items():
        rgb=hexa(cor)
        usa_branco = re.search(r'fill:\s*#[Ff]{3,6}\b', h) and cor.lower() in h.lower()
        c=contraste(branco,rgb)
        if usa_branco and c<4.5:
            avisos.append(f"há fill branco no doc e {nome} tem contraste {c:.1f}:1 com branco — conferir")
    ok("sem texto branco sobre cor de marca", not avisos, avisos[0] if avisos else "")

    # tabela larga rola no próprio container
    tabelas=h.count("<table")
    if tabelas:
        wrap=len(re.findall(r'overflow-x:\s*auto',h))
        ok("tabela em container com rolagem", wrap>0, f"{tabelas} tabelas, {wrap} regras de overflow-x")

    # acentuação
    ok("sem mojibake", "Ã§" not in h and "Ã£" not in h)

    # coerência: estados declarados vs contados (padrão dos painéis)
    est=Counter(re.findall(r'class="st st-(\w+)"',h))
    if est:
        total=sum(est.values())
        m=re.search(r'(\d+) de (\d+) itens',h)
        if m:
            ok("fração bate com o conteúdo", int(m.group(2))==total,
               f"afirma {m.group(2)}, contei {total}")
        m=re.search(r'(\d+) itens ·',h)
        if m:
            ok("rodapé bate com o conteúdo", int(m.group(1))==total,
               f"afirma {m.group(1)}, contei {total}")

    # alegações passadas na mão
    for claim in a.afirma:
        n=re.match(r'(\d+)\s+(\w+)',claim)
        if not n: continue
        qtd,coisa=int(n.group(1)),n.group(2)
        ok(f'alegação "{claim}"', claim in h, "não encontrei essa frase no doc")

    print()
    if falhas:
        print(f"REPROVOU em {len(falhas)}: {', '.join(falhas)}")
        sys.exit(1)
    print("passou em tudo" + (f" · {len(avisos)} aviso(s) pra olhar" if avisos else ""))

if __name__=="__main__":
    main()
