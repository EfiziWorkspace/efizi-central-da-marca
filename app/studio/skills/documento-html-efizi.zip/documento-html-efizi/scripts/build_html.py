#!/usr/bin/env python3
"""Empacota um documento HTML da Efizi: Manrope embutida, toggle de tema e wrapper.

  build_html.py corpo.html saida.html --titulo "..." [--desc "..."] [--sem-toggle]

O corpo é só o conteúdo (sem <html>/<head>/<body>); o wrapper é adicionado aqui.
Falha se sobrar placeholder de fonte.
"""
import argparse, base64, pathlib, subprocess, sys, tempfile

CDN = "https://cdn.jsdelivr.net/npm/@fontsource/manrope/files/manrope-latin-{w}-normal.woff2"
PESOS = (400, 600, 800)

def fontes():
    cache = pathlib.Path.home()/".cache"/"efizi-fonts"; cache.mkdir(parents=True, exist_ok=True)
    out = {}
    for w in PESOS:
        f = cache/f"manrope-{w}.woff2"
        if not f.exists():
            r = subprocess.run(["curl","-fsSL","--max-time","25",CDN.format(w=w),"-o",str(f)])
            if r.returncode or not f.exists() or f.stat().st_size < 5000:
                sys.exit(f"ERRO: não baixei a Manrope {w}. Sem fonte embutida não publica.")
        out[w] = base64.b64encode(f.read_bytes()).decode()
    return out

TOGGLE_CSS = """  .themetoggle{position:fixed;top:.75rem;right:.85rem;z-index:100;font-family:'Manrope',system-ui,sans-serif;font-size:.74rem;font-weight:700;color:var(--muted);background:var(--surface);border:1px solid var(--border);border-radius:999px;padding:.34rem .72rem;cursor:pointer;box-shadow:0 1px 2px rgba(0,0,0,.12),0 6px 16px rgba(0,0,0,.10);display:inline-flex;align-items:center;gap:.35rem;}
  .themetoggle:hover{color:var(--text);}
  .themetoggle:focus-visible{outline:2px solid var(--accent);outline-offset:2px;}
  @media print{.themetoggle{display:none;}}"""

TOGGLE_JS = """<script>
(function(){var root=document.documentElement,btn=document.getElementById('themebtn');
function apply(t){root.setAttribute('data-theme',t);btn.textContent=(t==='dark'?'\\u2600 claro':'\\u263e escuro');try{localStorage.setItem('efizi-theme',t)}catch(e){}}
var s=null;try{s=localStorage.getItem('efizi-theme')}catch(e){}
apply(s||'light');btn.addEventListener('click',function(){apply(root.getAttribute('data-theme')==='dark'?'light':'dark')});})();
</script>"""

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("corpo"); ap.add_argument("saida")
    ap.add_argument("--titulo", required=True); ap.add_argument("--desc", default="")
    ap.add_argument("--sem-toggle", action="store_true")
    a = ap.parse_args()

    corpo = pathlib.Path(a.corpo).read_text()
    fb = fontes()
    face = "\n".join(
        f"  @font-face{{font-family:'Manrope';font-weight:{w};font-style:normal;font-display:swap;"
        f"src:url(data:font/woff2;base64,{fb[w]}) format('woff2');}}" for w in PESOS)

    for w in PESOS:
        corpo = corpo.replace(f"@@FONT{w}@@", fb[w])
    if "@@FONT" in corpo:
        sys.exit("ERRO: sobrou placeholder de fonte no corpo.")

    toggle_css = "" if a.sem_toggle else TOGGLE_CSS
    toggle_btn = "" if a.sem_toggle else '<button id="themebtn" class="themetoggle" type="button" aria-label="Alternar claro e escuro">☾ escuro</button>\n'
    toggle_js  = "" if a.sem_toggle else TOGGLE_JS

    doc = f"""<!doctype html>
<html lang="pt-BR">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>{a.titulo}</title>
<meta name="description" content="{a.desc}">
<meta name="color-scheme" content="light dark">
<style>
{face}
  html{{color-scheme:light dark;background:var(--bg,#FBF9F6);}}
  body{{margin:0;padding:0;background:var(--bg,#FBF9F6);font-family:'Manrope',system-ui,sans-serif;}}
  img{{max-width:100%;}}
{toggle_css}
  @media print{{section,.card,.wave,.rule,.find{{break-inside:avoid;}} h2{{break-after:avoid;}}}}
</style>
</head>
<body>
{toggle_btn}{corpo}
{toggle_js}</body>
</html>
"""
    p = pathlib.Path(a.saida); p.parent.mkdir(parents=True, exist_ok=True); p.write_text(doc)
    print(f"gerado: {p}  ·  {len(doc)//1024} KB  ·  fontes embutidas: 3")

if __name__ == "__main__":
    main()
