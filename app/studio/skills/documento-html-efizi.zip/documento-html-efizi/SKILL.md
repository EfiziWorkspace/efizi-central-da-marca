---
name: documento-html-efizi
description: >
  Monta, verifica e publica documento HTML da Efizi — deck, painel, landing, mockup,
  e-mail ou tracker. Use SEMPRE que o pedido resultar num arquivo HTML pra alguém
  abrir ou receber: "monta um deck sobre X", "faz um painel de Y", "gera o HTML pra
  eu baixar", "cria uma landing", "atualiza o painel", "manda pro time", "salva na
  mesa". A skill aplica a casca da marca (Manrope embutida em base64, cores, tema
  claro e escuro, 100% offline), roda a verificação antes de entregar (contraste,
  fonte injetada, tabela rolando, números batendo com o conteúdo) e publica na ordem
  certa (cópia na mesa, artifact, commit). NÃO use para editar tema Shopify/Liquid,
  nem para e-mail transacional do n8n (esses têm skill própria).
---

# Documento HTML da Efizi

Todo documento que a Efizi entrega em HTML passa por três etapas. A ordem importa:
**montar → verificar → publicar.** Pular a verificação é o que produz os erros que já
aconteceram: texto ilegível sobre o laranja, contador dessincronizado do conteúdo,
botão que dispara a ação errada, fonte não embutida quebrando o arquivo offline.

## 1 · Montar

**Sempre**, sem exceção:

- **Manrope embutida em base64** nos pesos 400, 600 e 800. Zero CDN, zero Google Fonts.
  O arquivo tem que abrir offline e por e-mail. Use `scripts/build_html.py` — ele baixa
  do fontsource, injeta e falha se sobrar placeholder.
- **Cores da marca**, nunca hex solto no meio do HTML. Tokens em `assets/tokens.css`:
  laranja `#FF4000` (ênfase, uma por peça), amarelo `#FFD500` (selo/alerta), ink
  `#0A0A0A`, cream. Teal só em UI digital.
- **Tema claro e escuro**, abrindo no **claro**, com toggle que lembra a escolha.
  Já vem em `assets/tokens.css` + `scripts/build_html.py`.
- **Uma cor de ênfase por peça.** Não pintar tudo de laranja.
- **Sentence case** em títulos. Body 18-22px (o público tem 40+).
- **Sem travessão** no texto, e sem "Atenciosamente"/"Prezado".
- **`@media print`** que não corta card, seção ou tabela no meio.

### Escolha o molde pelo formato

| Formato | Molde de referência |
|---|---|
| **Deck / apresentação** | `~/efizi-manual-de-marca/apresentacao-template/index.html` (17 moldes) e `banco.html` (fotos). **Usar, não recriar.** |
| **Painel / dashboard** | `~/Desktop/Efizi-AI-first/Painel-roadmap-AI-first.html` — seções, KPIs, tabelas com rolagem própria |
| **App / mockup navegável** | `~/Desktop/Efizi-AI-first/Mockup-Command-Center.html` — nav lateral, panes, estado |
| **Landing** | `~/efizi-manual-de-marca/landing-html/` |

Deck e painel são bichos diferentes: deck é slide, uma ideia por tela, navegação por
teclado; painel é rolagem contínua e densidade de dado. Não misture as estruturas.

## 2 · Verificar (antes de entregar, sempre)

Rode `scripts/verificar.py <arquivo>`. Ele checa:

- **Fonte** — nenhum `@@FONT` sobrando; 3 `@font-face` com base64
- **Offline** — zero `src=`/`href=` apontando para `http`
- **Contraste** — texto sobre `#FF4000` e `#FFD500` precisa de tinta escura, não branco
  (branco sobre o laranja dá 3,5:1 e reprova)
- **Tabela larga** — dentro de container com `overflow-x:auto`
- **Acentuação** — sem mojibake
- **Coerência numérica** — se o documento afirma "N itens" ou "X%", conferir contra o
  que ele de fato contém. Erro real já cometido: um item contado duas vezes inflando
  o total.

Se o documento tem interação (botão, aba, filtro), **teste no navegador**: sirva local
e dirija por JS. Erro real já cometido: um botão "Fechar" caindo no handler de recusar.

## 3 · Publicar (nesta ordem)

1. **Cópia autônoma na mesa** — `~/Desktop/<Projeto>/<Nome>.html`, com `<!doctype>`,
   `<meta charset>`, `<title>` e `<meta name="description">`. É o que ele abre e manda.
2. **Artifact** — mesma URL de sempre para o mesmo documento (republicar o mesmo
   `file_path`). Nunca mintar URL nova para um doc que já existe.
3. **Commit no repositório**, quando o documento pertence a um — os do AI-first vivem
   em `EfiziWorkspace/command-center` em `docs/`.

Depois, abrir no Chrome com cache-buster: `open -a "Google Chrome" "file://<path>?v=$(date +%H%M%S)"`.
Sem isso o Chrome reabre a aba antiga e ele vê a versão velha.

## Regras que já custaram caro

- **A regra na memória não se aplica sozinha.** O deck de reposicionamento, com 50
  slides, saiu sem Manrope embutida mesmo com a regra registrada. Por isso ela mora
  aqui, num procedimento, e não só como preferência.
- **Documento é do time ou é dele?** Se vai circular, tirar julgamento sobre pessoas.
  Verdade sobre o negócio fica, mesmo desconfortável; julgamento sobre gente sai.
  Uma versão só, nunca duas: elas desencontram em semanas.
- **Marcar só a exceção.** Selo repetido em tudo vira papel de parede. Se a maior parte
  é real, marque só o que é exemplo.
