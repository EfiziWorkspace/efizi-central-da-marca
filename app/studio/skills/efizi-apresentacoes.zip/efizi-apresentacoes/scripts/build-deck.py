#!/usr/bin/env python3
"""
Empacota um deck da Efizi (index.html + deck-stage.js + brandbook/deck-v4.css + img/)
num único HTML autossuficiente, em dois modos:

  standalone  -> documento completo, tudo embutido (fonte base64, imagens base64,
                 CSS e deck-stage.js inline). Abre com duplo-clique, offline, em
                 qualquer computador. É o que se manda pro time / sobe no Drive.

  fragment    -> versão LEVE sem <html>/<head>/<body> (fragmento de corpo) + override
                 do position:fixed, pra hospedar como página web (Netlify Drop etc.).
                 As fotos entram reduzidas (padrão 1280px) pra o arquivo ficar leve.
                 ATENÇÃO: o Artifact do claude.ai NÃO roda deck de tela cheia; use
                 hospedagem estática de verdade (ver reference de entrega).

Uso:
  python3 build-deck.py <pasta_do_deck> [--mode standalone|fragment] [--out arq.html]
                        [--maxpx 1280] [--quality 66]

<pasta_do_deck> é a pasta que contém index.html e img/. A raiz do repo (onde ficam
brandbook/ , deck-stage.js e assets/) é inferida como a pasta-mãe. Rode toda vez que
o deck mudar (texto, imagem, animação).
"""
import base64, re, os, sys, argparse, subprocess, tempfile, urllib.request

CHROME_UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
             "(KHTML, like Gecko) Chrome/120 Safari/537.36")
# Google Fonts só devolve woff2 pra UA de Chrome desktop; com UA de Safari vem TTF e
# a fonte não embute. Não troque isso sem testar embedded:True.

def read(p):
    with open(p, "r", encoding="utf-8") as f: return f.read()

def b64file(p):
    with open(p, "rb") as f: return base64.b64encode(f.read()).decode()

def resolve_css(path, seen=None):
    """Inline recursivo da cadeia de @import locais do deck-v4.css. @import http (Google
       Fonts) é descartado — a fonte entra por @font-face base64 (embed_manrope)."""
    if seen is None: seen = set()
    path = os.path.abspath(path)
    if path in seen: return ""
    seen.add(path)
    base = os.path.dirname(path); out = []
    for line in read(path).splitlines():
        m = re.search(r'@import\s+url\(\s*["\']([^"\')]+)["\']\s*\)', line)
        if m:
            if m.group(1).startswith("http"): continue
            out.append(resolve_css(os.path.join(base, m.group(1)), seen)); continue
        out.append(line)
    return "\n".join(out)

def embed_manrope():
    api = ("https://fonts.googleapis.com/css2?"
           "family=Manrope:wght@400;500;600;700;800&display=swap")
    try:
        css = urllib.request.urlopen(
            urllib.request.Request(api, headers={"User-Agent": CHROME_UA}), timeout=25).read().decode()
        faces = []
        for blk in re.findall(r'@font-face\s*{[^}]+}', css):
            wm = re.search(r'font-weight:\s*(\d+)', blk)
            um = re.search(r'src:\s*url\(([^)]+\.woff2)\)', blk)
            rm = re.search(r'unicode-range:\s*([^;]+);', blk)
            if not (wm and um): continue
            if rm and 'U+0000' not in rm.group(1): continue   # só subset latin (cobre pt-BR)
            data = urllib.request.urlopen(
                urllib.request.Request(um.group(1), headers={"User-Agent": CHROME_UA}), timeout=25).read()
            faces.append("@font-face{font-family:'Manrope';font-style:normal;font-weight:%s;"
                         "font-display:swap;src:url(data:font/woff2;base64,%s) format('woff2');}"
                         % (wm.group(1), base64.b64encode(data).decode()))
        if faces: return "\n".join(faces), True
    except Exception as e:
        sys.stderr.write("font embed falhou (%r) — caindo no @import online\n" % e)
    return ("@import url('%s');" % api), False

def b64_image(path, maxpx=None, quality=None):
    """Base64 do JPEG. Se maxpx/quality vierem, reduz via sips (macOS) antes."""
    if maxpx:
        tmp = tempfile.mktemp(suffix=".jpg")
        subprocess.run(["sips", "-Z", str(maxpx), "-s", "format", "jpeg",
                        "-s", "formatOptions", str(quality or 66), path, "--out", tmp],
                       check=True, capture_output=True)
        data = open(tmp, "rb").read(); os.remove(tmp)
    else:
        data = open(path, "rb").read()
    return base64.b64encode(data).decode(), len(data)

def build(deck_dir, mode, out, maxpx, quality, permitir_fonte_online=False):
    deck_dir = os.path.abspath(deck_dir)
    root = os.path.dirname(deck_dir)
    combined_css = resolve_css(os.path.join(root, "brandbook", "deck-v4.css"))
    fontface, embedded = embed_manrope()

    # O embed da fonte busca na rede e falha de vez em quando. O fallback é um @import
    # online, que faz o deck depender de internet para renderizar com a tipografia certa.
    # Antes isso passava como uma linha "embutida: False" no meio do relatório, e o arquivo
    # saía assim mesmo. Agora aborta: é melhor não ter arquivo do que ter um que quebra na
    # sala de reunião.
    if not embedded and not permitir_fonte_online:
        sys.exit(
            "\nERRO: nao consegui embutir a fonte Manrope (a busca na rede falhou).\n"
            "  O deck ficaria dependente de internet para renderizar certo, entao nao gravei nada.\n"
            "  O que fazer: rode de novo, a falha costuma ser passageira.\n"
            "  Se precisar gerar assim mesmo: --permitir-fonte-online\n"
        )

    combined_css = fontface + "\n" + combined_css

    html = read(os.path.join(deck_dir, "index.html"))
    link_tag = '<link rel="stylesheet" href="../brandbook/deck-v4.css">'
    assert link_tag in html, "tag <link> do css nao encontrada em index.html"
    html = html.replace(link_tag, "<style>\n" + combined_css + "\n</style>")

    script_tag = '<script src="../deck-stage.js" defer></script>'
    assert script_tag in html, "tag <script> do deck-stage nao encontrada"
    html = html.replace(script_tag, "<script>\n" + read(os.path.join(root, "deck-stage.js")) + "\n</script>")

    lite = (mode == "fragment")
    total = 0
    # Percorre img/ INTEIRA, incluindo subpastas. O banco de fotos do template mora em
    # img/banco/, então varrer só o primeiro nível deixava toda foto de fora e o deck
    # quebrava fora da pasta, em silêncio.
    img_root = os.path.join(deck_dir, "img")
    for dirpath, _dirnames, filenames in os.walk(img_root):
        for fn in sorted(filenames):
            if not fn.lower().endswith((".jpg", ".jpeg")):
                continue
            full = os.path.join(dirpath, fn)
            rel = os.path.relpath(full, deck_dir).replace(os.sep, "/")
            if ('src="%s"' % rel) not in html:
                continue  # imagem não usada por este deck: não embute
            b64, n = b64_image(full, maxpx if lite else None, quality if lite else None)
            total += n
            html = html.replace('src="%s"' % rel, 'src="data:image/jpeg;base64,%s"' % b64)

    # Embute QUALQUER svg de ../assets/ que o deck referencie. A lista fixa de duas logos
    # deixava de fora a logo escura (efizi-logo.svg), usada em capa creme.
    for svg in sorted(set(re.findall(r'src="\.\./assets/([^"]+\.svg)"', html))):
        p = os.path.join(root, "assets", svg)
        if os.path.exists(p):
            html = html.replace('src="../assets/%s"' % svg,
                                'src="data:image/svg+xml;base64,%s"' % b64file(p))

    if lite:
        head_inner = html.split("<head>", 1)[1].split("</head>", 1)[0]
        body_inner = html.split("<body>", 1)[1].rsplit("</body>", 1)[0]
        override = ("<style>html,body{margin:0!important;padding:0!important;height:100%;"
                    "background:#000;overflow:hidden}deck-stage{position:relative!important;"
                    "display:block!important;inset:auto!important;width:100vw!important;height:100vh!important}</style>")
        html = head_inner.strip() + "\n" + override + "\n" + body_inner.strip() + "\n"

    with open(out, "w", encoding="utf-8") as f: f.write(html)

    # A checagem ignora comentários HTML e CSS: o próprio template documenta o caminho de
    # exemplo `src="img/banco/...jpg"` dentro de um comentário, e um falso positivo aqui
    # ensina o time a ignorar o aviso, que é pior do que não ter aviso nenhum.
    sem_comentario = re.sub(r'<!--.*?-->', '', html, flags=re.S)
    sem_comentario = re.sub(r'/\*.*?\*/', '', sem_comentario, flags=re.S)
    leftover = re.findall(r'(?:src|href)="(\.\./[^"]+|img/[^"]+|https?://[^"]+)"', sem_comentario)
    print("OK ->", out)
    print("modo:", mode, "| tamanho: %.2f MB" % (os.path.getsize(out) / (1024*1024)))
    print("fonte Manrope embutida:", embedded)
    if lite: print("fotos reduzidas somadas: %.2f MB" % (total / (1024*1024)))
    print("referencias externas restantes:", leftover if leftover else "nenhuma")

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("deck_dir", help="pasta com index.html e img/")
    ap.add_argument("--mode", choices=["standalone", "fragment"], default="standalone")
    ap.add_argument("--out", default=None)
    ap.add_argument("--maxpx", type=int, default=1280, help="lado maior das fotos no modo fragment")
    ap.add_argument("--quality", type=int, default=66, help="qualidade JPEG no modo fragment")
    ap.add_argument("--permitir-fonte-online", action="store_true",
                    help="gera mesmo sem embutir a Manrope (o deck passa a depender de internet)")
    a = ap.parse_args()
    out = a.out or os.path.expanduser(
        "~/Desktop/%s-%s.html" % (os.path.basename(os.path.abspath(a.deck_dir)), a.mode))
    build(a.deck_dir, a.mode, out, a.maxpx, a.quality, a.permitir_fonte_online)

if __name__ == "__main__":
    main()
