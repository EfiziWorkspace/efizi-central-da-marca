# Motion e interações do deck-stage

Todo o motion e toda a interação vivem **só no `index.html` do deck** (bloco `<style>` +
`<script>` no fim). Nunca editar o `deck-stage.js` — ele é compartilhado com o brandbook
e com outros decks; quebrar lá quebra tudo. As técnicas abaixo foram desenhadas
exatamente pra não precisar tocar nele.

O `deck-stage` marca o slide ativo com `[data-deck-active]` e dispara um CustomEvent
`slidechange` (`e.detail.index`, `.previousIndex`, `.total`, `.slide`). Ele expõe
`stage.goTo/next/prev/index/length` e um método interno `stage._go(target, reason)` por
onde passam TODAS as navegações (teclado, botões do overlay, tap). Sobrescrever `_go`
é como se intercepta um slide sem mexer no componente.

Regra de ouro: gatilhar tudo em `@media (prefers-reduced-motion: no-preference)` e ancorar
em `[data-deck-active]`, pra a animação re-disparar a cada entrada no slide e respeitar
quem desliga motion.

---

## 1. Entrada de conteúdo (cascata) — já no template
Filhos de `.slide-pad` sobem 24px + fade, em cascata por `nth-child` (keyframe `deckRise`).
Slides de FOTO ficam de fora (`:not(.photo)`) — eles têm motion próprio (seção 3).

## 2. Revelação por clique (interceptando `stage._go`)
O padrão-mãe. Serve pra qualquer "aperta a seta e revela mais". Estrutura:

```js
(function(){
  function init(){
    var stage = document.querySelector('deck-stage');
    var slide = document.getElementById('slide-X');
    if(!stage || !slide || typeof stage._go !== 'function') return;
    var IDX = Array.prototype.indexOf.call(stage.children, slide);
    slide.classList.add('x-js');
    var step = -1;                    // -1 = vazio; comece VAZIO se quiser clicar pra abrir o 1º
    function render(){ /* aplica o estado do 'step' via classes */ }
    var origGo = stage._go.bind(stage);
    stage._go = function(target, reason){
      var cur = stage.index;
      if(cur===IDX && target===IDX+1 && nextStep()){ stage._flashOverlay&&stage._flashOverlay(); return; }
      if(cur===IDX && target===IDX-1 && prevStep()){ stage._flashOverlay&&stage._flashOverlay(); return; }
      return origGo(target, reason);   // pulos e outros slides passam direto
    };
    stage.addEventListener('slidechange', function(e){
      if(e.detail.index!==IDX){ /* limpar timers */ return; }
      showUpTo(e.detail.previousIndex > IDX ? LAST : -1); // de trás: cheio; da frente: vazio
    });
    if(stage.index===IDX) showUpTo(-1);
    if(document.fonts) document.fonts.ready.then(function(){ if(stage.index===IDX) showUpTo(step); });
  }
  customElements.whenDefined('deck-stage').then(function(){ setTimeout(init,0); });
})();
```

Vários interceptadores convivem: cada um checa seu próprio `IDX`, então dá pra ter 4-5
slides interativos no mesmo deck (as sobrescritas de `_go` se encadeiam). Sempre entrar
em estado "instantâneo" (classe tipo `.x-instant` que zera transições) ao ENTRAR/ao
redimensionar, pra nada deslizar do canto; depois remover a classe.

Sabores já construídos e testados:
- **Stepper com moldura laranja** (`.rm-stepper`): grade de cards; uma `.wave-glow` absoluta
  lê `offsetLeft/Top/Width/Height` do card ativo e desliza com `cubic-bezier(.34,1.35,.5,1)`.
  Começa VAZIO (só título) e cada clique abre um card. Opcional: uma frase-remate `.rm-auto`
  que surge SOZINHA ~640ms depois do último card (via `setTimeout`).
- **Revelação binária** (a "virada"): entra mostrando um lado; a seta revela o outro (slide-in +
  blur→nítido + cor da marca) e recua o lado antigo (`opacity:.45`).
- **Cadência automática** (o "mercado"): NÃO intercepta `_go`; ao entrar de frente roda uma
  sequência de `setTimeout` que revela blocos em ritmo de leitura, sem clique.
- **Trilha em SVG que sobe**: nós + segmentos (stroke-dashoffset desenhando) + marcador que
  climba (`transform` com transição). Ótimo pra jornada/escada. Labels em `<text>` SVG.

## 3. Motion das capas com foto
Cada abertura de ato tem uma animação sob medida na `.bg` (keyframe próprio), pensada pra
composição/ponto de fuga daquela foto. Dois cuidados que mordem:

- **Dissolve a partir do preto** (evita corte seco ao entrar em capa com foto): dar
  `background:#0a0a0a` na `.slide.photo` e somar uma 2ª animação `deckPhotoIn` (opacity 0→1,
  ~1s) à do pan/zoom em cada `.bg`. Lê como fade-through-black e mascara o corte. Conteúdo
  da capa entra com um `deckPhotoTextIn` (delay ~.35s).
- **Overscan**: em pan (translateX) mantenha escala base **≥ 1.10**, senão a borda preta
  aparece. Verifique medindo os gaps do `.bg` vs. o pai nos dois extremos (devem ser negativos).
- Zoom-in aproxima (ternura/foco); zoom-out "abre o mundo" (bom pra virar de ato). ease-out
  começa forte; ease-in-out demora a começar (evite se quiser impacto imediato).

## 4. Números que giram (count-up)
`requestAnimationFrame` interpolando de 0 ao alvo com easeOutCubic; formata com vírgula
decimal (pt-BR) e sufixo (`90M`, `8,9%`). **Bug que já explodiu:** ao sair do slide, limpar
`setTimeout` NÃO cancela os rAF pendentes → frames obsoletos sobrescrevem o valor final.
Solução: um **token de geração** (`gen++` ao sair) e o frame aborta se `myGen !== gen`, mais
`cancelAnimationFrame`.

## 5. Gatilhos e verificação
- **Hash de reload**: o deck guarda a posição no `location.hash` (`#N` = slide N, 1-based).
  Ao recarregar o preview, ele pode reabrir num slide interativo — e aí `goTo(idx±1)` de teste
  vira next/prevStep em vez de navegar. Testar sempre **partindo de um slide distante**.
- **Preview em aba de fundo**: `requestAnimationFrame` PAUSA (números ficam em 0), mas
  `setTimeout` e transições CSS rodam. Pra conferir número final, entrar no slide **por trás**
  (o caminho "instantâneo" fixa o estado cheio sem rAF). Pra conferir uma animação CSS, usar a
  Web Animations API: `el.getAnimations()[0].currentTime = t` e amostrar o `transform`.
- Toda revelação precisa de **fallback sem JS**: sem o `.x-js`, tudo aparece aceso (pra
  impressão/PDF via `@media print`, que o deck-stage já dá — um slide por página).
