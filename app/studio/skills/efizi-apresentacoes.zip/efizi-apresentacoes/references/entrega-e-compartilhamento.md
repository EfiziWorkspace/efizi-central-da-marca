# Entrega e compartilhamento do deck

O deck de trabalho (`.../algum-deck/index.html`) **não** pode ser mandado sozinho: ele
puxa `../brandbook/deck-v4.css`, `../deck-stage.js`, `img/*.jpg` e a fonte por fora. Fora
da pasta, quebra. O que se entrega é sempre um HTML **empacotado** pelo `scripts/build-deck.py`.

## Gerar o arquivo
```
python3 <skill>/scripts/build-deck.py <pasta_do_deck> --mode standalone
```
- **`--mode standalone`** (padrão): documento completo, tudo embutido (fonte Manrope base64,
  imagens base64, CSS e deck-stage.js inline), 100% offline. Sai em `~/Desktop/<deck>-standalone.html`.
  É o que se manda pro time e o que sobe no Drive. Rode toda vez que o deck mudar.
- **`--mode fragment`**: versão LEVE (fotos reduzidas) e sem `<html>/<head>/<body>`, pra
  hospedar como página web. Só serve pra hospedagem estática (ver abaixo).

Sempre confira a saída do script: `fonte Manrope embutida: True` e `referencias externas
restantes: nenhuma`. Se sobrar referência, o arquivo quebra em outro computador.

## A fonte viaja embutida (dúvida recorrente)
Quem receber o `standalone` **não precisa ter a Manrope instalada**, nem internet: a fonte
está em `@font-face` base64 dentro do próprio arquivo (5 pesos, subset latin que cobre os
acentos do pt-BR). Renderiza idêntico em Windows/Mac/celular. É o motivo de o arquivo ter
vários MB. (Só a versão de TRABALHO, que busca a fonte por fora, quebraria a tipografia.)

## Como compartilhar — régua testada
1. **Mandar o arquivo direto / AirDrop / pen drive** — sempre funciona, é só abrir no navegador.
2. **Google Drive** — subir o `standalone` (dá pra copiar pra dentro da pasta do Drive Desktop
   montada em `~/Library/CloudStorage/GoogleDrive-.../Meu Drive/`, que sincroniza sozinho).
   Depois **Compartilhar → "Qualquer pessoa com o link" → Leitor** (as ferramentas de Drive aqui
   LEEM permissão mas não ALTERAM — esse passo é manual). Avisar que o Drive **não roda HTML**:
   a pessoa vê "sem visualização" e **baixa** pra abrir no navegador. Ótimo pra distribuir; ruim
   pra "abrir e apresentar na hora".
3. **Link que abre e apresenta sem baixar** — precisa de **hospedagem estática de verdade**:
   - **Netlify Drop** (netlify.com/drop): arrasta o HTML, cospe um link público na hora. Mais rápido.
   - Vercel / GitHub Pages: também servem, mais setup.

## ⚠️ O Artifact do claude.ai NÃO serve pra esse deck
Testado e confirmado: publicar o deck como Artifact renderiza **em branco**. O deck é um app
de tela cheia (web component `deck-stage` + `position:fixed` + canvas escalado por JS) e o
sandbox do Artifact não roda isso — nem reduzindo pra ~2 MB, nem forçando o `position:fixed`.
O `--mode fragment` foi feito pensando nisso, mas o destino dele é hospedagem estática
(Netlify/Vercel/Pages), **não** o Artifact. Não gastar tempo tentando o Artifact pra deck.

## Versionamento
Conteúdo de apresentação é versionado **só local** (não empurrar pro repo de design system —
se um dia for pro git, criar um repo dedicado a apresentações). O `standalone` na Mesa é a
cópia de entrega; regerar a cada mudança.
