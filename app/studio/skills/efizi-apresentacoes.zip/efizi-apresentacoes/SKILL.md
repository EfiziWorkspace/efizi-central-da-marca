---
name: efizi-apresentacoes
description: >
  Monta, anima e entrega apresentações (decks) da Efizi no componente deck-stage —
  vários slides pra projetar/apresentar, com navegação por teclado, revelação por
  clique e motion nas capas com foto. Use SEMPRE que o pedido for sobre uma
  APRESENTAÇÃO ou DECK de múltiplos slides: "monta uma apresentação sobre X", "cria
  um deck pro time", "adiciona um slide", "anima o slide Y", "faz revelação por
  clique / passo a passo", "põe um efeito na capa com foto", "gera o arquivo pra eu
  apresentar/compartilhar", "publica a apresentação", "transforma isso num deck",
  "como eu compartilho essa apresentação". Prevalece sobre a documento-html-efizi
  quando o resultado é um deck de vários slides no deck-stage. NÃO use para documento
  de uma página (painel, landing, e-mail, tracker → documento-html-efizi), nem para
  tema/PDP Shopify, nem para e-mail do n8n.
---

# Apresentações (decks) da Efizi

Um deck da Efizi é um HTML de vários slides rodando no web component **`deck-stage`**
(canvas fixo 1920×1080 escalado pra caber na tela, letterbox), com a marca aplicada
(Manrope, tokens, tema claro/escuro), navegação por teclado, notas do apresentador e
impressão um-slide-por-página. É diferente de um documento de uma página — por isso
tem skill própria.

O trabalho segue uma sequência que o Guilherme fixou e que evita retrabalho:
**fechar todo o conteúdo → depois imagens → depois transições.** Não adiante motion
nem troca de foto antes do conteúdo estar aprovado. Dentro disso, o ciclo é
**montar → animar → entregar.**

## Onde as coisas moram
- **Template do time**: `~/efizi-manual-de-marca/apresentacao-template/` (index.html com 17
  moldes de slide + banco.html de fotos + LEIA-ME). Começar um deck novo daqui, não do zero.
- **Componente**: `~/efizi-manual-de-marca/deck-stage.js` — compartilhado, **nunca editar**.
- **Casca da marca**: `~/efizi-manual-de-marca/brandbook/deck-v4.css` (puxa deck.css, tokens…).
- **Fontes verbais** (MVV, manifesto, estratégia): `~/efizi-manual-de-marca/dna/`. Textos
  fundacionais entram **verbatim** do dna, sem parafrasear.

## 1. Montar
- Partir do template; cada slide é um `<section class="slide …">` filho de `<deck-stage>`.
  Classes úteis: `cream`, `dark`, `orange`, `photo` (capa full-bleed com `.bg`+`.scrim`).
- Calibrar pra TV/projeção: tipografia generosa, texto enxuto, um slide = uma ideia.
- **Copy da marca**: sem travessão "—" (soa a IA); sem "Atenciosamente"/"Prezado"; explicar
  antes de nomear (o público — e o próprio Guilherme — trava em jargão: "canal", "on-site",
  "lastro"). Preferir carro-chefe, no local, histórico de obras, responsabilidade técnica.
- **Notas do apresentador**: uma por slide, na ordem, no `<script type="application/json"
  id="speaker-notes">`. Abrem/fecham na tecla **N**. É onde vai o detalhe que polui o slide
  (ex.: o "ele ganha / a Efizi ganha" de cada etapa).
- Rodapé NN/TOTAL é automático via JS; teclas: setas/espaço navega, **F** fullscreen, **R** reset.
- Fechar a versão no chat antes de gravar — alinhar, e só então salvar.

## 2. Animar
Todo o motion vive no `index.html` do deck (nunca no deck-stage.js). O kit de técnicas —
revelação por clique interceptando `stage._go` (stepper com moldura, revelação binária,
cadência automática, trilha SVG), motion de capa com dissolve-do-preto e a regra do overscan,
count-up de números, e os gatilhos que já morderam (bug do rAF obsoleto, hash de reload,
preview em aba de fundo) — está em **`references/motion-e-interacoes.md`**. Ler antes de animar.

Princípio: escolher o movimento que serve à ideia daquele slide, não um efeito genérico em
tudo (Ken Burns em tudo foi reprovado). Sutil e sob medida > chamativo e uniforme.

## 3. Entregar
Nunca mandar o `index.html` de trabalho (quebra fora da pasta). Empacotar com o script:

```
python3 <esta-skill>/scripts/build-deck.py <pasta_do_deck> --mode standalone
```

Sai um HTML autossuficiente na Mesa (fonte + imagens embutidas, offline) — é o que se manda
pro time / sobe no Drive. Conferir na saída: `fonte Manrope embutida: True` e `referencias
externas restantes: nenhuma`. Regerar a cada mudança do deck.

Como compartilhar (Drive = baixa e abre · **Artifact do claude.ai NÃO roda deck** · Netlify
Drop = link que abre e apresenta), a dúvida "funciona sem a fonte instalada?" (sim, viaja
embutida) e o modo `--mode fragment` pra hospedagem web: tudo em
**`references/entrega-e-compartilhamento.md`**.

## Verificar antes de entregar
- Sem overflow (texto cortado), numeração sequencial, todas as imagens carregam, console limpo.
- As revelações têm fallback sem JS (aparecem acesas).
- No preview local (server "brandbook", porta 4173): viewport largo (1440×810) e recarregar
  após editar. Animações não avançam em aba de fundo — validar pela Web Animations API.
